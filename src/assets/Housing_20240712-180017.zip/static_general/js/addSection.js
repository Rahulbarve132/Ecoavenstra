let isFormVisible = false;

function addSection(existingUserInput) {
  const existingUserOption = 'Restaurant'; // Adjust this based on your actual data structure

  const sectionId = `section-${existingUserOption.toLowerCase()}`;
  const formHTML = `
    <div class="flex flex-col justify-center items-center gap-4 w-full ">
                    <div id="dialogue-box"
                        class="relative bg-purple-100 p-4 rounded-lg flex flex-col justify-between items-start w-[80%]">
                        <!-- Wrapper div for buttons -->
                        <div class="absolute z-20  w-[95%] inline-block h-full hidden delete-button-wrapper ">
                            <!-- Other buttons -->
                            <div
                                class="flex justify-center items-center space-x-4 p-2 heading-buttons transition-all duration-300 bg-blue-500 rounded-lg m-auto">
                                <!-- Edit button -->
                                <button class="text-slate-100 hover:text-yellow-600 focus:outline-none edit-btn">
                                    <span class="material-icons">edit</span>
                                    <span class="button-text">Edit Text</span>
                                </button>
                            </div>
                            <!-- Delete button -->
                            <button
                                class="absolute top-0 right-0 hover:text-red-600 focus:outline-none wrapper-delete-btn">
                                <span class="material-icons text-3xl">delete</span>
                            </button>
                        </div>
                        <button
                            class="absolute z-30 text-center right-3 top-2 text-3xl text-purple-600 toggle-btn focus:outline-none">+</button>
                        <p class="text-2xl  text-purple-800">3. What types of properties are available in Itārsi?</p>
                        <div id="additional-content" class="hidden mt-4 mx-6">
                            <p class="text-lg text-purple-800">You can find a wide range of properties in Itārsi,
                                including luxurious villas, spacious apartments, commercial spaces, and serene
                                countryside estates. Whatever your real estate needs, Itārsi has something to offer.</p>
                            <button
                                class="absolute top-0 right-3 z-30 text-center text-5xl text-purple-600  close-btn focus:outline-none">-</button>
                        </div>
                        <div class="absolute top-0 left-0 w-full h-full hover:delete-button-wrapper"></div>
                    </div>


                </div>
  `;

  document.getElementById('AddSection').insertAdjacentHTML('beforeend', formHTML);
  isFormVisible = true;
}
