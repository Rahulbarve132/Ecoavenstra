let isFormVisible = false;
let targetSection = null;

function addSection(existingUserInput) {
  const existingUserOption = 'Restaurant'; // Adjust this based on your actual data structure

  // Capture the clicked button's parent section
  targetSection = event.target.closest('.hover-section-buttons');

  const sectionId = `section-${existingUserOption.toLowerCase()}`;
  const formHTML = `
      <div id="${sectionId}" class="fixed inset-0 flex items-center justify-center z-20 draggable-section">
          <div class="bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl shadow-2xl p-8 w-11/12 max-w-2xl mx-auto">
              <p style="display: none;">Using user input: <span>${existingUserInput}</span></p>
              <p style="display: none;">Using user option: <span>${existingUserOption}</span></p>
              <div class="flex justify-between items-center mb-6">
                  <h2 class="text-2xl font-bold text-gray-800">Add Section</h2>
                  <button class="text-gray-600 hover:text-gray-800 transition-colors duration-200" onclick="closeAddSectionModal()">
                      <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                  </button>
              </div>
              <div class="space-y-6">
                  <div>
                      <label for="sectionType" class="block text-sm font-medium text-gray-700 mb-2">Section Type:</label>
                      <div class="relative">
                          <select name="sectionType" class="form-select block w-full pl-10 pr-4 py-3 text-base border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 rounded-md shadow-sm transition-colors duration-200" required>
                              <option value="team">Team</option>
                              <option value='gallery'>Map Location</option>
                          </select>
                          
                      </div>
                  </div>
                  <div class="flex justify-end space-x-4">
                      <button class="px-6 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-md shadow-md hover:from-red-600 hover:to-pink-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 transition-all duration-200" onclick="closeAddSectionModal()">
                          Close
                      </button>
                      <button type="button" onclick="submitSection()" class="px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-md shadow-md hover:from-blue-600 hover:to-indigo-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-all duration-200">
                          Submit
                      </button>
                  </div>
              </div>
          </div>
      </div>
  `;

  document.getElementById('AddSection').style.display = 'block';
  document.getElementById('AddSection').insertAdjacentHTML('beforeend', formHTML);
  isFormVisible = true;
}

function closeAddSectionModal() {
  document.getElementById('AddSection').style.display = 'none';
}

let loaderTimer;

function submitSection() {
  const sectionType = document.querySelector('.form-select[name="sectionType"]').value;
  const userInput = document.querySelector('p[style="display: none;"]:first-child span').innerHTML;
  const userOption = document.querySelector('p[style="display: none;"]:nth-child(2) span').textContent;

  // Show loader
  showLoader();

  const formData = new FormData();
  formData.append('user_input', userInput);
  formData.append('section_type', sectionType);
  formData.append('user_option', userOption);

  fetch('/add_section', {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      if (sectionType === 'text') {
        handleTextSection(data);
      } else if (sectionType === 'team') {
        handleTeamSection(data, targetSection);
      } else if (sectionType === 'quote') {
        handleQuoteSection(data, targetSection);
      } else if (sectionType === 'feature') {
        handleFeatureSection(data, targetSection);
      } else if (sectionType === 'services') {
        handleServicesSection(data, targetSection);
      } else if (sectionType === 'clients') {
        handleClientsSection(data, targetSection);
      } else if (sectionType === 'testimonials') {
        handleTestimonialsSection(data, targetSection);
      } else if (sectionType === 'gallery') {
        handleLocationSection(data, targetSection);
      } else {
        console.log('Unsupported section type:', sectionType);
      }

      // Remove the submitted form
      const submittedForm = document.querySelector('.draggable-section');
      if (submittedForm) {
        submittedForm.parentNode.removeChild(submittedForm);
      }
    })
    .catch(error => {
      console.error('Error:', error);
    });

  closeAddSectionModal();
}

function showLoader() {
  // First, remove any existing loader
  hideLoader();

  const loaderHTML = `
    <div id="loader" class="fixed inset-0 flex flex-col items-center justify-center z-50 backdrop-filter backdrop-blur-md bg-opacity-50">
      <div class="w-16 h-16 relative mb-4">
        <div class="absolute w-full h-full border-4 border-t-4 border-blue-500 rounded-full animate-spin"></div>
        <div class="absolute w-full h-full border-4 border-t-4 border-indigo-500 rounded-full animate-ping" style="animation-delay: -0.5s;"></div>
      </div>
      <p class="text-xl font-semibold text-gray-700">Generating Section...</p>
    </div>
  `;
  document.body.insertAdjacentHTML('beforeend', loaderHTML);

  // Set a timer to hide the loader after exactly 8 seconds
  loaderTimer = setTimeout(hideLoader, 8000);
}

function hideLoader() {
  const loader = document.getElementById('loader');
  if (loader) {
    loader.remove();
  }
  // Clear the timer to prevent any potential issues
  if (loaderTimer) {
    clearTimeout(loaderTimer);
    loaderTimer = null;
  }
}

// Ensure hideLoader is called when the page is unloaded
window.addEventListener('beforeunload', hideLoader);




function handleLocationSection(data, targetSection) {
  if (!targetSection) {
    console.error('Error: targetSection is null');
    return;
  }

  console.log("location section data:", data);

  // Create the main container
  const mainContainer = document.createElement('section');
  mainContainer.id = 'locationsection';
  mainContainer.className = 'relative group hover-section-buttons bg-gray-100 py-16 px-4 sm:px-6 lg:px-8';

  // Use the existing HTML structure for the location section
  mainContainer.innerHTML = `
    <button id="addSectionbtn" class="btn btn-primary add-section-button" onclick="addSection('${data.user_query}')">Add Section</button>

    <div class="absolute top-4 right-3 z-10 flex md:justify-end justify-center items-center mt-8 md:mt-4 md:mr-8 ml-4 md:ml-0 space-x-2 w-full opacity-0 transition-opacity duration-300 group-hover:opacity-100">
      <button class="text-gray-500 hover:text-red-700 focus:outline-none delete-section" data-target-section="locationsection">
        <span class="material-icons">delete</span>
      </button>
      <button onclick="moveSection('locationsection', 'up')" class="text-gray-500 hover:text-blue-700 focus:outline-none">
        <span class="material-icons">arrow_upward</span>
      </button>
      <button onclick="moveSection('locationsection', 'down')" class="text-gray-500 hover:text-blue-700 focus:outline-none">
        <span class="material-icons">arrow_downward</span>
      </button>
      <button class="text-gray-500 hover:text-gray-700 focus:outline-none hide-btn" data-target-section="locationsection">
        <span class="material-icons">visibility</span>
      </button>
    </div>
    <div class="max-w-6xl mx-auto">
      <div class="relative flex flex-col items-center justify-center" data-hover-target="locationSectionTitleEdit">
        <h2 id="locationSectionTitle" class="text-4xl sm:text-4xl font-extrabold text-gray-900 mb-10 text-center">Visit Our Office</h2>

        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons opacity-0 transition-opacity duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg" data-hover-show="locationSectionTitleEdit">
          <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="showSingleEditModal('locationSectionTitle')">
            <span class="material-icons">create</span>
            <span class="button-text">Edit</span>
          </button>
        </div>
      </div>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <div class="space-y-8">
          <div class="relative bg-white rounded-xl shadow-lg p-6 sm:p-8" data-hover-target="locationSectionContactInfo">
            <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons opacity-0 transition-opacity duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg" data-hover-show="locationSectionContactInfo">
              <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="openEditContactInfo()">
                <span class="material-icons">create</span>
                <span class="button-text">Edit</span>
              </button>
            </div>
            <h3 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Contact Information</h3>
            <ul class="space-y-4 text-gray-600">
              <li class="flex items-center">
                <svg class="h-6 w-6 sm:h-7 sm:w-7 text-emerald-600 mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <span id="locationSectionAddress" class="text-base sm:text-lg">123 Business Avenue, Enterprise City, BZ 12345</span>
              </li>
              <li class="flex items-center">
                <svg class="h-6 w-6 sm:h-7 sm:w-7 text-emerald-600 mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <span id="locationSectionPhone" class="text-base sm:text-lg">+1 (555) 123-4567</span>
              </li>
              <li class="flex items-center">
                <svg class="h-6 w-6 sm:h-7 sm:w-7 text-emerald-600 mr-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span id="locationSectionEmail" class="text-base sm:text-lg">info@businessexample.com</span>
              </li>
            </ul>
          </div>
          <div class="relative bg-white rounded-xl shadow-lg p-6 sm:p-8" data-hover-target="locationSectionBusinessHoursEdit">
            <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons opacity-0 transition-opacity duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg" data-hover-show="locationSectionBusinessHoursEdit">
              <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="openEditBusinessHours()">
                <span class="material-icons">create</span>
                <span class="button-text">Edit</span>
              </button>
            </div>
            <h3 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6">Business Hours</h3>
            <ul class="space-y-3 text-gray-600">
              <li class="flex justify-between items-center">
                <span class="text-base sm:text-lg font-medium">Monday - Friday:</span>
                <span id="weekdayHours" class="text-base sm:text-lg">9:00 AM - 6:00 PM</span>
              </li>
              <li class="flex justify-between items-center">
                <span class="text-base sm:text-lg font-medium">Saturday:</span>
                <span id="saturdayHours" class="text-base sm:text-lg">10:00 AM - 4:00 PM</span>
              </li>
              <li class="flex justify-between items-center">
                <span class="text-base sm:text-lg font-medium">Sunday:</span>
                <span id="sundayHours" class="text-base sm:text-lg">Closed</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="h-[400px] sm:h-[500px] lg:h-full">
          <div class="editMapLocationBtn">
            <button id="googleMapBtn" class="bg-gradient-to-r from-blue-500 to-teal-400 text-white font-bold py-2 px-4 rounded-lg md:rounded-r-full shadow-lg hover:from-blue-600 hover:to-teal-500 transition duration-300 ease-in-out flex items-center">
              <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
              </svg>
              Edit Location
            </button>
          </div>
          <div class="h-full w-full overflow-hidden rounded-xl shadow-xl">
            <iframe id="mapIframe" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215549799732!2d-73.98509668459469!3d40.74844097932847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9b3117469%3A0xd134e199a405a163!2sEmpire%20State%20Building!5e0!3m2!1sen!2sus!4v1625684679212!5m2!1sen!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" class="w-full h-full"></iframe>
          </div>
        </div>
      </div>
    </div>
  `;

  // Insert the main container before the target section
  targetSection.insertAdjacentElement('beforebegin', mainContainer);

  // Attach event listeners and hover effects
  attachEventListenersAndHoverEffects(mainContainer);
}

function attachEventListenersAndHoverEffects(container) {
  // Attach event listener for the "Edit Location" button
  const googleMapBtn = container.querySelector('#googleMapBtn');
  if (googleMapBtn) {
    googleMapBtn.addEventListener('click', () => {
      const editMapModal = document.getElementById('editMapModal');
      if (editMapModal) {
        editMapModal.classList.remove('hidden');
      }
    });
  }

  // Attach hover effects for edit buttons
  const hoverTargets = container.querySelectorAll('[data-hover-target]');
  hoverTargets.forEach(target => {
    const hoverShow = target.querySelector('[data-hover-show]');
    if (hoverShow) {
      target.addEventListener('mouseenter', () => {
        hoverShow.classList.remove('opacity-0');
        hoverShow.classList.add('opacity-100');
      });
      target.addEventListener('mouseleave', () => {
        hoverShow.classList.remove('opacity-100');
        hoverShow.classList.add('opacity-0');
      });
    }
  });

  // Attach event listeners for edit buttons
  const editContactInfoBtn = container.querySelector('[onclick="openEditContactInfo()"]');
  if (editContactInfoBtn) {
    editContactInfoBtn.addEventListener('click', openEditContactInfo);
  }

  const editBusinessHoursBtn = container.querySelector('[onclick="openEditBusinessHours()"]');
  if (editBusinessHoursBtn) {
    editBusinessHoursBtn.addEventListener('click', openEditBusinessHours);
  }
}

function openEditContactInfo() {
  const editContactInfoModal = document.getElementById('editContactInfo');
  if (editContactInfoModal) {
    editContactInfoModal.classList.remove('hidden');
    populateContactInfoModal();
  }
}

function openEditBusinessHours() {
  const editBusinessHoursModal = document.getElementById('editBusinessHours');
  if (editBusinessHoursModal) {
    editBusinessHoursModal.classList.remove('hidden');
    populateBusinessHoursModal();
  }
}

function populateContactInfoModal() {
  document.getElementById('editLocationSectionAddress').value = document.getElementById('locationSectionAddress').textContent.trim();
  document.getElementById('editLocationSectionPhone').value = document.getElementById('locationSectionPhone').textContent.trim();
  document.getElementById('editLocationSectionEmail').value = document.getElementById('locationSectionEmail').textContent.trim();
}

function populateBusinessHoursModal() {
  document.getElementById('editWeekdayHours').value = document.getElementById('weekdayHours').textContent.trim();
  document.getElementById('editSaturdayHours').value = document.getElementById('saturdayHours').textContent.trim();
  document.getElementById('editSundayHours').value = document.getElementById('sundayHours').textContent.trim();
}

function closeEditContactInfo() {
  document.getElementById('editContactInfo').classList.add('hidden');
}

function closeEditBusinessHours() {
  document.getElementById('editBusinessHours').classList.add('hidden');
}

function showSingleEditModal(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    const currentText = element.textContent.trim();
    const newText = prompt('Enter new text:', currentText);
    if (newText !== null && newText !== '') {
      element.textContent = newText;
    }
  }
}


function saveContactInfo() {
  const address = document.getElementById('editLocationSectionAddress').value;
  const phone = document.getElementById('editLocationSectionPhone').value;
  const email = document.getElementById('editLocationSectionEmail').value;

  document.getElementById('locationSectionAddress').textContent = address;
  document.getElementById('locationSectionPhone').textContent = phone;
  document.getElementById('locationSectionEmail').textContent = email;

  closeEditContactInfo();
}

function saveBusinessHours() {
  const weekdayHours = document.getElementById('editWeekdayHours').value;
  const saturdayHours = document.getElementById('editSaturdayHours').value;
  const sundayHours = document.getElementById('editSundayHours').value;

  document.getElementById('weekdayHours').textContent = weekdayHours;
  document.getElementById('saturdayHours').textContent = saturdayHours;
  document.getElementById('sundayHours').textContent = sundayHours;

  closeEditBusinessHours();
}

function editMapLocation() {
  const editMapModal = document.getElementById('editMapModal');
  if (editMapModal) {
    editMapModal.classList.remove('hidden');
  }
}

function saveMapLocation() {
  const mapUrl = document.getElementById('editMapUrl').value;
  const mapIframe = document.getElementById('mapIframe');
  if (mapIframe && mapUrl) {
    mapIframe.src = mapUrl;
  }
  closeEditMapModal();
}

function closeEditMapModal() {
  const editMapModal = document.getElementById('editMapModal');
  if (editMapModal) {
    editMapModal.classList.add('hidden');
  }
}

// Add this function to handle the section title edit
function saveSectionTitle() {
  const newTitle = document.getElementById('editSectionTitle').value;
  document.getElementById('locationSectionTitle').textContent = newTitle;
  closeSectionTitleEditModal();
}

function closeSectionTitleEditModal() {
  const editTitleModal = document.getElementById('editSectionTitleModal');
  if (editTitleModal) {
    editTitleModal.classList.add('hidden');
  }
}

// Modify the showSingleEditModal function to use a modal for section title edit
function showSingleEditModal(elementId) {
  const editSingleHeadingModal = document.getElementById('editSingleHeadingModal');
  const editSingleHeadingText = document.getElementById('editSingleHeadingText');
  const element = document.getElementById(elementId);

  if (editSingleHeadingModal && editSingleHeadingText && element) {
    editSingleHeadingText.value = element.textContent.trim();
    editSingleHeadingModal.classList.remove('hidden');
    
    // Store the current element ID for later use
    editSingleHeadingModal.dataset.currentElementId = elementId;
  }
}
function updateSingleHeadingContent() {
  const editSingleHeadingModal = document.getElementById('editSingleHeadingModal');
  const editSingleHeadingText = document.getElementById('editSingleHeadingText');
  const currentElementId = editSingleHeadingModal.dataset.currentElementId;
  const element = document.getElementById(currentElementId);

  if (element && editSingleHeadingText) {
    element.textContent = editSingleHeadingText.value;
  }

  hideEditSingleHeadingModal();
}
function hideEditSingleHeadingModal() {
  const editSingleHeadingModal = document.getElementById('editSingleHeadingModal');
  if (editSingleHeadingModal) {
    editSingleHeadingModal.classList.add('hidden');
  }
}

// Add event listeners when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function () {
  // Attach event listeners for save buttons in modals
  const saveContactInfoBtn = document.getElementById('saveContactInfoBtn');
  if (saveContactInfoBtn) {
    saveContactInfoBtn.addEventListener('click', saveContactInfo);
  }

  const saveBusinessHoursBtn = document.getElementById('saveBusinessHoursBtn');
  if (saveBusinessHoursBtn) {
    saveBusinessHoursBtn.addEventListener('click', saveBusinessHours);
  }

  const saveMapLocationBtn = document.getElementById('saveMapLocationBtn');
  if (saveMapLocationBtn) {
    saveMapLocationBtn.addEventListener('click', saveMapLocation);
  }

  const saveSectionTitleBtn = document.getElementById('saveSectionTitleBtn');
  if (saveSectionTitleBtn) {
    saveSectionTitleBtn.addEventListener('click', saveSectionTitle);
  }

  // Attach event listeners for close buttons in modals
  const closeButtons = document.querySelectorAll('.close-modal');
  closeButtons.forEach(button => {
    button.addEventListener('click', function () {
      const modal = this.closest('.modal');
      if (modal) {
        modal.classList.add('hidden');
      }
    });
  });
});



// Team section
function handleTeamSection(data, targetSection) {
  if (!targetSection) {
    console.error('Error: targetSection is null');
    return;
  }

  const teamContainer = document.createElement('div');

  console.log("team section data:", data);

  // Clear the existing content of the team container
  teamContainer.innerHTML = '';

  // Create the main container with appropriate classes
  const mainContainer = document.createElement('div');
  mainContainer.id = 'team-section';
  mainContainer.className = 'container mx-auto py-8 flex flex-col items-center justify-center group hover-section-buttons';

  // Add the "Add Section" button
  const addSectionButton = document.createElement('button');
  addSectionButton.id = 'addSectionbtn';
  addSectionButton.className = 'btn btn-primary add-section-button';
  addSectionButton.setAttribute('onclick', `addSection('${data.user_query}')`);
  addSectionButton.textContent = 'Add Section';
  mainContainer.appendChild(addSectionButton);

  // Create the buttons for delete, move up, move down, and hide/visible
  const sectionButtonsContainer = document.createElement('div');
  sectionButtonsContainer.className = 'flex justify-end items-center mt-8 w-full space-x-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100';

  sectionButtonsContainer.innerHTML = `
    <button class="text-gray-500 hover:text-red-700 focus:outline-none delete-section" data-target-section="team-section">
      <span class="material-icons">delete</span>
    </button>
    <button class="text-gray-500 hover:text-blue-700 focus:outline-none" onclick="moveSection('team-section', 'up')">
      <span class="material-icons">arrow_upward</span>
    </button>
    <button class="text-gray-500 hover:text-blue-700 focus:outline-none" onclick="moveSection('team-section', 'down')">
      <span class="material-icons">arrow_downward</span>
    </button>
    <button class="text-gray-500 hover:text-gray-700 focus:outline-none hide-btn service-section__btn-hideshow" id="button4" data-target-section="team-section">
      <span class="material-icons">visibility</span>
    </button>
  `;
  mainContainer.appendChild(sectionButtonsContainer);

  // Create the heading for the team section
  const headingContainer = document.createElement('div');
  headingContainer.className = 'relative';
  const heading = document.createElement('h1');
  heading.id = 'team-heading';
  heading.className = 'text-3xl font-bold text-center mb-8';
  heading.textContent = 'Meet Our Expert Team';
  headingContainer.appendChild(heading);

  // Edit button for the heading
  const headingEditButtons = document.createElement('div');
  headingEditButtons.className = 'absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg';
  headingEditButtons.innerHTML = `
    <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="showSingleEditModal('team-heading')">
      <span class="material-icons">create</span>
      <span class="button-text">Edit</span>
    </button>
  `;
  headingContainer.appendChild(headingEditButtons);
  mainContainer.appendChild(headingContainer);

  // Create the flex container for team members
  const teamMembersContainer = document.createElement('div');
  teamMembersContainer.id = 'team-container';
  teamMembersContainer.className = 'flex flex-col md:flex-row justify-center space-y-6 md:space-y-0 md:space-x-6';

  // Loop to create team members
  for (let i = 0; i < 3; i++) {
    const teamMember = document.createElement('div');
    teamMember.className = 'text-center';

    // Extract team member data
    const title = data.result[`team_title_${i + 1}`];
    const description = data.result[`team_description_${i + 1}`];
    const imageSrc = data.result[`team_member_image_${i + 1}`];

    // Create unique IDs for team title and description elements
    const titleId = `team-m${i + 1}-title`;
    const descriptionId = `team-m${i + 1}-desc`;
    const imageId = `team-img${i + 1}`;
    const imageInputId = `team_image_input${i + 1}`;

    teamMember.innerHTML = `
      <div class="image-wrapper">
        <img class="rounded-lg w-48 h-48 object-cover mx-auto" src="/static/static_general/img/Team-m-2.png" alt="" id="${imageId}">
        <input type="file" id="${imageInputId}" accept="image/png, image/jpeg" style="display: none;">
        <div class="upload-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 space-x-4 p-2 hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">
          <button class="upload-button text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded" onclick="uploadImage('${imageId}','${imageInputId}')">
            <span class="material-icons">upload</span>
            <span class="tooltip-text">Upload Image</span>
          </button>
        </div>
      </div>
      <div class="relative">
        <h2 id="${titleId}" class="mt-4 text-xl font-semibold">Team Member</h2>
        <p id="${descriptionId}" class="text-gray-600">Member Designation</p>
        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">
          <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="showEditModal('${titleId}','${descriptionId}')">
            <span class="material-icons">create</span>
            <span class="button-text">Edit</span>
          </button>
        </div>
      </div>
    `;

    // Append the created team member to the team members container
    teamMembersContainer.appendChild(teamMember);
  }

  // Append the team members container to the main container
  mainContainer.appendChild(teamMembersContainer);

  // Add the "Add Items" button
  const addItemButton = document.createElement('div');
  addItemButton.className = 'button-container';
  addItemButton.innerHTML = `
    <button id="addItemButton" class="bg-slate-800 font-semibold text-md p-2 my-12 rounded-lg text-white" onclick="addItemToTeams()">Add Items</button>
  `;
  mainContainer.appendChild(addItemButton);

  // Insert the main container before the target section
  targetSection.insertAdjacentElement('beforebegin', mainContainer);
}




function handleTextSection(data) {
  const textContainer = document.getElementById('text');
  const newSection = document.createElement('div');
  newSection.className = 'container my-5 py-5 text-center draggable-section';

  const titleId = 'title1';
  const descriptionId = 'description1';

  newSection.innerHTML = `
          <button id="button30" onclick="moveSection('text', 'up')" class="btn btn-secondary">Move Up</button>
            <button id="button31" onclick="moveSection('text', 'down')" class="btn btn-secondary">Move Down</button>
    <button onclick="regenerateContent('${titleId}', 'regenerate_title_for_textsection'); regenerateContent('${descriptionId}', 'regenerate_description_for_textsection')">Regenerate Content</button>
    <h1 id='${titleId}'>${data.result.title1}</h1>
    <p id='${descriptionId}' style="font-size: 20px;">${data.result.description1}</p>
  `;

  textContainer.appendChild(newSection);
}

function regeneratecontent(itemId, regenerationType) {
  var user_input = document.getElementById(itemId).innerText.trim();
  var user_org = document.getElementById('title1').innerText.trim();

  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/regenerate_content', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // Update the innerHTML of the corresponding element with the new content
      document.getElementById(itemId).innerHTML = JSON.parse(xhr.responseText).regenerated_content;
    }
  };
  xhr.send('user_input=' + encodeURIComponent(user_input) + '&user_org=' + encodeURIComponent(user_org) + '&regeneration_type=' + encodeURIComponent(regenerationType));
}

// function handleTeamSection(data) {
//   const teamContainer = document.getElementById('team'); // Replace 'team' with the actual ID of your team container

//   console.log("team section data:",data)

//   // Create a container for team members
//   const teamMembersContainer = document.createElement('div');
//   teamMembersContainer.className = 'row g-4';
//   // Create move buttons outside the loop
//   const moveButtons = document.createElement('div');
//   moveButtons.className = 'move-buttons';
//   moveButtons.innerHTML = `
//   <button id="button30" onclick="moveSection('team', 'up')" class="btn btn-secondary">Move Up</button>
//   <button id="button31" onclick="moveSection('team', 'down')" class="btn btn-secondary">Move Down</button>
//   `;
//   teamContainer.appendChild(moveButtons);

//   // Loop to create team members
//   for (let i = 0; i < 3; i++) {
//       const teamMember = document.createElement('div');
//       teamMember.className = 'col-lg-4 col-md-6 wow fadeInUp';
//       teamMember.setAttribute('data-wow-delay', `0.${i + 1}s`);

//       // Extract team member data
//       const title = data.result[`team_title_${i + 1}`];
//       let description = data.result[`team_description_${i + 1}`];

//       // Add "Title:" before the team member's title
//       const titleWithLabel = `${title} \n`;

//       // Check if "Description:" label is present
//       // if (description.includes('Description:')) {
//       //     // Remove "Description:" label and add a new line
//       //     description = description.replace('Description:', '\n');
//       // }

//       // Create unique IDs for team title and team description elements
//       const titleId = `teamtitle_${i + 1}`;
//       const descriptionId = `teamdescription_${i + 1}`;

//       // Create unique IDs for regenerate button
//       const regenerateButtonId = `regenerate_button_${i + 1}`;

//       teamMember.innerHTML = `

//           <button onclick="regenerateContent('${titleId}', 'regenerate_title_for_teamsection'); regenerateContent('${descriptionId}', 'regenerate_description_for_teamsection')">Regenerate Content</button>
//           <div class="room-item shadow rounded overflow-hidden">
//               <div class="position-relative">
//                   <img class="img-fluid" src="${data.result[`team_member_image_${i + 1}`]}" width="408" height="200" alt="">
//               </div>
//               <div class="p-4 mt-2">
//                   <div class="d-flex justify-content-between mb-3">
//                       <h5 id="${titleId}" class="mb-0">${titleWithLabel}</h5><br>
//                   </div>
//                   <p id="${descriptionId}" class="text-body mb-3">${description}</p>
//                   <div class="d-flex justify-content-between">
//                       <!-- Add other content here if needed -->
//                   </div>
//               </div>

//           </div>
//       `;

//       // Append the created team member to the team members container
//       teamMembersContainer.appendChild(teamMember);
//   }

//   // Append the team members container to the teamContainer
//   teamContainer.appendChild(teamMembersContainer);
// }

// function handleTeamSection(data, targetSection) {
//   if (!targetSection) {
//     console.error('Error: targetSection is null');
//     return;
//   }

//   const teamContainer = document.createElement('div');

//   console.log("team section data:", data);

//   // Clear the existing content of the team container
//   teamContainer.innerHTML = '';

//   // Create the main container with appropriate classes
//   const mainContainer = document.createElement('div');
//   mainContainer.className = 'container mx-auto py-8';

//   // Create the heading for the team section
//   const heading = document.createElement('h1');
//   heading.className = 'text-3xl font-bold text-center mb-8';
//   heading.textContent = 'Meet Our Expert Team at Jodha, Indore';
//   mainContainer.appendChild(heading);

//   // Create the flex container for team members
//   const teamMembersContainer = document.createElement('div');
//   teamMembersContainer.className = 'flex flex-col md:flex-row justify-center space-y-6 md:space-y-0 md:space-x-6';

//   // Create move buttons outside the loop
//   const moveButtons = document.createElement('div');
//   moveButtons.className = 'move-buttons text-center mb-4';
//   moveButtons.innerHTML = `
//     <button id="button30" onclick="moveSection('team', 'up')" class="btn btn-secondary mx-2">Move Up</button>
//     <button id="button31" onclick="moveSection('team', 'down')" class="btn btn-secondary mx-2">Move Down</button>
//   `;
//   mainContainer.appendChild(moveButtons);

//   // Loop to create team members
//   for (let i = 0; i < 3; i++) {
//     const teamMember = document.createElement('div');
//     teamMember.className = 'text-center';

//     // Extract team member data
//     const title = data.result[`team_title_${i + 1}`];
//     const description = data.result[`team_description_${i + 1}`];
//     const imageSrc = data.result[`team_member_image_${i + 1}`];

//     // Create unique IDs for team title and description elements
//     const titleId = `teamtitle_${i + 1}`;
//     const descriptionId = `teamdescription_${i + 1}`;

//     teamMember.innerHTML = `
//       <img class="rounded-lg w-48 h-48 object-cover mx-auto" src="${imageSrc}" alt="${title}">
//       <h2 id="${titleId}" class="mt-4 text-xl font-semibold">${title}</h2>
//       <p id="${descriptionId}" class="text-gray-600">${description}</p>
//       <button onclick="regenerateContent('${titleId}', 'regenerate_title_for_teamsection'); regenerateContent('${descriptionId}', 'regenerate_description_for_teamsection')" class="mt-2 btn btn-primary">Regenerate Content</button>
//     `;

//     // Append the created team member to the team members container
//     teamMembersContainer.appendChild(teamMember);
//   }

//   // Append the team members container to the main container
//   mainContainer.appendChild(teamMembersContainer);

//   // Insert the main container before the target section
//   targetSection.insertAdjacentElement('beforebegin', mainContainer);
// }



function handleQuoteSection(data) {
  const quoteContainer = document.getElementById('quote-container'); // Replace 'quote-container' with the actual ID of your quote container

  // Extract quote data
  const quote = data.result['quote_content'];

  // Display the quote on the website
  quoteContainer.innerHTML = `
  <button onclick="regeneratecontent('quotedata', 'regenerate_quote')">Regenerate Content</button>
  <button id="button30" onclick="moveSection('quote-container', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('quote-container', 'down')" class="btn btn-secondary">Move Down</button>

      <div class="quote-item">
          <p id='quotedata' class="quote-text">${quote}</p>
      </div>
  `;
}

function handleFeatureSection(data) {
  const featuresContainer = document.getElementById('features-container'); // Replace 'features' with the actual ID of your features container

  // Create a container for features
  const featuresItemsContainer = document.createElement('div');
  featuresItemsContainer.className = 'row g-4';
  const moveButtons = document.createElement('div');
  moveButtons.className = 'move-buttons';
  moveButtons.innerHTML = `
  <button id="button30" onclick="moveSection('features-container', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('features-container', 'down')" class="btn btn-secondary">Move Down</button>
  `;
  featuresContainer.appendChild(moveButtons);
  // Loop to create feature items
  for (let i = 0; i < 3; i++) {
    const featureItem = document.createElement('div');
    featureItem.className = 'col-lg-4 col-md-6 wow fadeInUp';
    featureItem.setAttribute('data-wow-delay', `0.${i + 1}s`);

    // Extract feature data
    const title = data.result[`feature_title_${i + 1}`];
    let description = data.result[`feature_description_${i + 1}`];

    // Add "Title:" before the feature title
    const titleWithLabel = `${title} \n`;

    // Check if "Description:" label is present

    const titleId = `featuretitle_${i + 1}`;
    const descriptionId = `featuredescription_${i + 1}`;

    // Create unique IDs for regenerate button
    const regenerateButtonId = `regenerate_button_${i + 1}`;

    featureItem.innerHTML = `
    <button onclick="regenerateContent('${titleId}', 'regenerate_title_for_featuresection'); regenerateContent('${descriptionId}', 'regenerate_description_for_featuresection')">Regenerate Content</button>
      <div class="feature-item shadow rounded overflow-hidden">
        <div class="position-relative">
          <img class="img-fluid" src="${data.result[`team_member_image_${i + 1}`]}" width="408" height="200" alt="">              
        </div>
        <div class="p-4 mt-2">
          <div class="d-flex justify-content-between mb-3">
            <h5 id='${titleId}' class="mb-0">${titleWithLabel}</h5><br>
          </div>
          <p id='${descriptionId}' class="text-body mb-3">${description}</p>
          <div class="d-flex justify-content-between">
            <!-- Add other content here if needed -->
          </div>
        </div>
      </div>
    `;

    // Append the created feature item to the features items container
    featuresItemsContainer.appendChild(featureItem);
  }

  // Append the feature items container to the featuresContainer
  featuresContainer.appendChild(featuresItemsContainer);
}
function handleServicesSection(data) {
  const servicesContainer = document.getElementById('services-container'); // Replace 'features' with the actual ID of your features container


  const servicesItemsContainer = document.createElement('div');
  servicesItemsContainer.className = 'row g-4';
  const moveButtons = document.createElement('div');
  moveButtons.className = 'move-buttons';
  moveButtons.innerHTML = `
  <button id="button30" onclick="moveSection('services-container', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('services-container', 'down')" class="btn btn-secondary">Move Down</button>
  `;
  servicesContainer.appendChild(moveButtons);

  for (let i = 0; i < 3; i++) {
    const serviceItem = document.createElement('div');
    serviceItem.className = 'col-lg-4 col-md-6 wow fadeInUp';
    serviceItem.setAttribute('data-wow-delay', `0.${i + 1}s`);

    // Extract feature data
    const title = data.result[`service_title_${i + 1}`];
    let description = data.result[`service_description_${i + 1}`];

    // Add "Title:" before the feature title
    const titleWithLabel = `${title} \n`;

    // Check if "Description:" label is present

    const titleId = `servicetitle_${i + 1}`;
    const descriptionId = `servicedescription_${i + 1}`;

    // Create unique IDs for regenerate button
    const regenerateButtonId = `regenerate_button_${i + 1}`;

    serviceItem.innerHTML = `
    <button onclick="regenerateContent('${titleId}', 'regenerate_title_for_servicesection'); regenerateContent('${descriptionId}', 'regenerate_description_for_servicesection')">Regenerate Content</button>
      <div class="service-item shadow rounded overflow-hidden">
        <div class="position-relative">
          <img class="img-fluid" src="${data.result[`team_member_image_${i + 1}`]}" width="408" height="200" alt="">              
        </div>
        <div class="p-4 mt-2">
          <div class="d-flex justify-content-between mb-3">
            <h5 id='${titleId}' class="mb-0">${titleWithLabel}</h5><br>
          </div>
          <p id='${descriptionId}' class="text-body mb-3">${description}</p>
          <div class="d-flex justify-content-between">
            <!-- Add other content here if needed -->
          </div>
        </div>
      </div>
    `;

    // Append the created feature item to the features items container
    servicesItemsContainer.appendChild(serviceItem);
  }

  // Append the feature items container to the featuresContainer
  servicesContainer.appendChild(servicesItemsContainer);
}


function handleClientsSection(data) {
  const clientsContainer = document.getElementById('clients'); // Replace 'clients' with the actual ID of your clients container

  // Create a container for clients
  const clientsContentContainer = document.createElement('div');
  clientsContentContainer.className = 'row g-4';

  // Create a dialogue container
  const dialogueContainer = document.createElement('div');
  dialogueContainer.className = 'col-lg-6 col-md-12 wow fadeInUp';

  dialogueContainer.innerHTML = `
    <div class="dialogue-container p-4">
    <button id="button30" onclick="moveSection('clients', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('clients', 'down')" class="btn btn-secondary">Move Down</button>
      <h2 class="text-black mb-4">Working With the Best Clients and Partners</h2>
    </div>
  `;

  // Append the dialogue container to the clients content container
  clientsContentContainer.appendChild(dialogueContainer);

  // Create a container for client images
  const clientsImagesContainer = document.createElement('div');
  clientsImagesContainer.className = 'col-lg-6 col-md-12 wow fadeInUp';

  // Loop to create client images in rows of three
  for (let i = 0; i < 6; i += 3) {
    const clientRow = document.createElement('div');
    clientRow.className = 'row';

    for (let j = 0; j < 3; j++) {
      const clientImage = document.createElement('div');
      clientImage.className = 'col-md-4'; // Adjust the column width as needed

      // Extract client image data
      const clientImageUrl = data.result[`client_image_${i + j + 1}`];

      clientImage.innerHTML = `
        <img class="client-image" src="${clientImageUrl}" alt="Client ${i + j + 1}" style="width: 150px; height: 200px;">
      `;

      // Append the created client image to the row
      clientRow.appendChild(clientImage);
    }

    // Append the row to the clients images container
    clientsImagesContainer.appendChild(clientRow);
  }

  // Append the clients images container to the clients content container
  clientsContentContainer.appendChild(clientsImagesContainer);

  // Append the clients content container to the clientsContainer
  clientsContainer.appendChild(clientsContentContainer);
}


function handleTestimonialsSection(data) {
  const testimonialsContainer = document.getElementById('testimonials-container'); // Replace 'testimonials' with the actual ID of your testimonials container
  const moveButtons = document.createElement('div');
  moveButtons.className = 'move-buttons';
  moveButtons.innerHTML = `
  <button id="button30" onclick="moveSection('testimonials-container', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('testimonials-container', 'down')" class="btn btn-secondary">Move Down</button>
  `;
  testimonialsContainer.appendChild(moveButtons);
  // Loop through testimonial data
  for (let i = 0; i < 4; i++) {
    // const titleId = `testimonialid_${i + 1}`;
    const testimony = data.result[`testimony_${i + 1}`];

    // Create testimonial element
    const testimonialElement = document.createElement('div');
    testimonialElement.className = 'testimonial';

    // Set testimonial content
    testimonialElement.innerHTML = `
      <p>${testimony}</p>
    `;

    // Append testimonial element to testimonials container
    testimonialsContainer.appendChild(testimonialElement);
  }
}
function handleGallerySection(data) {
  const galleryContainer = document.getElementById('gallery-container'); // Replace 'gallery-container' with the actual ID of your gallery container

  // Create a container for gallery items
  const galleryItemsContainer = document.createElement('div');
  galleryItemsContainer.className = 'row g-4';
  const moveButtons = document.createElement('div');
  moveButtons.className = 'move-buttons';
  moveButtons.innerHTML = `
  <button id="button30" onclick="moveSection('gallery-container', 'up')" class="btn btn-secondary">Move Up</button>
  <button id="button31" onclick="moveSection('gallery-container', 'down')" class="btn btn-secondary">Move Down</button>
  `;
  galleryContainer.appendChild(moveButtons);
  // Loop to create gallery items
  for (let i = 0; i < 10; i++) { // Adjust the loop range based on the number of gallery items you want to display
    const galleryItem = document.createElement('div');
    galleryItem.className = 'col-lg-4 col-md-6 wow fadeInUp';
    galleryItem.setAttribute('data-wow-delay', `0.${i + 1}s`);

    // Extract gallery data
    const imageUrl = data.result[`gallery_image_${i + 1}`];

    galleryItem.innerHTML = `
      <div class="gallery-item shadow rounded overflow-hidden">
        <div class="position-relative">
          <img class="img-fluid" src="${imageUrl}"  width="400" height="300">              
        </div>
        
      </div>
    `;

    // Append the created gallery item to the gallery items container
    galleryItemsContainer.appendChild(galleryItem);
  }

  // Append the gallery items container to the galleryContainer
  galleryContainer.appendChild(galleryItemsContainer);
}


// ... (moveSeection function remains unchanged)

function moveSeection(sectionId, direction) {
  const section = document.getElementById(sectionId);
  const container = section.parentElement;
  const index = Array.from(container.children).indexOf(section);

  if (direction === 'up' && index > 0) {
    container.insertBefore(section, container.children[index - 1]);
  }

  if (direction === 'down' && index < container.children.length - 1) {
    container.insertBefore(container.children[index + 1], section);
  }
}

// Function to handle drag start event
function handleDragStart(e) {
  e.dataTransfer.setData('text/plain', e.target.parentElement.id);
}

const resultContainer = document.getElementById('resultContainer');

resultContainer.addEventListener('dragover', function (e) {
  e.preventDefault();
});

resultContainer.addEventListener('drop', function (e) {
  e.preventDefault();

  const draggedId = e.dataTransfer.getData('text/plain');
  const draggedElement = document.getElementById(draggedId);

  // Assuming you want to move sections within the resultContainer:
  resultContainer.appendChild(draggedElement); // Or use insertBefore for more control
});
