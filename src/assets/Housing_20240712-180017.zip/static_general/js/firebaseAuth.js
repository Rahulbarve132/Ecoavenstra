// import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
//         import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
//         import { getFirestore, setDoc, doc } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";

//         const firebaseConfig = {
//             apiKey: "AIzaSyCB-0xopi_33x2OulQDCyOPFYbPh9J1dHo",
//             authDomain: "growthziauth.firebaseapp.com",
//             projectId: "growthziauth",
//             storageBucket: "growthziauth.appspot.com",
//             messagingSenderId: "304008080757",
//             appId: "1:304008080757:web:a896f6680db733b644773c"
//         };

//         const app = initializeApp(firebaseConfig);
//         const auth = getAuth();
//         const db = getFirestore(app);

//         const signUpForm = document.getElementById('signupFormElement');
//         signUpForm.addEventListener('submit', (event) => {
//             event.preventDefault();
//             const email = document.getElementById('signupEmail').value;
//             const password = document.getElementById('signupPassword').value;
//             const name = document.getElementById('name').value;

//             createUserWithEmailAndPassword(auth, email, password)
//                 .then((userCredential) => {
//                     const user = userCredential.user;
//                     const userData = {
//                         email: email,
//                         name: name,
//                     };
//                     alert("Account created successfully");
//                     const docRef = doc(db, "users", user.uid);
//                     return setDoc(docRef, userData);
//                 })
//                 .then(() => {
//                     fetch('/submit', {
//                         method: 'POST',
//                         headers: {
//                             'Content-Type': 'application/json',
//                         },
//                         body: JSON.stringify({
//                             email: email,
//                             name: name
//                         })
//                     })
//                     .then(response => response.json())
//                     .then(data => {
//                         console.log('Success:', data);
//                         window.location.href = 'index.html';
//                     })
//                     .catch((error) => {
//                         console.error('Error:', error);
//                     });
//                 })
//                 .catch((error) => {
//                     const errorCode = error.code;
//                     if (errorCode == 'auth/email-already-in-use') {
//                         alert("Email Address Already Exists !!!");
//                     } else {
//                         alert("Unable to create user");
//                         console.error("Unable to create user", errorCode);
//                     }
//                 });
//         });