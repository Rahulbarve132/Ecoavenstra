// Add these global variables for timings
let editMondaySaturdayInput, editSundayInput, editAddressInput, editPhoneInput, editEmailInput, editTwitterInput, editFacebookInput, editYouTubeInput, editLinkedInInput;

function initializeEditTimingsInputs() {
    editMondaySaturdayInput = document.getElementById('editMondaySaturday');
    editSundayInput = document.getElementById('editSunday');
}

function initializeEditFooterInputs() {
    editAddressInput = document.getElementById('editAddress');
    editPhoneInput = document.getElementById('editPhone');
    editEmailInput = document.getElementById('editEmail');
    editTwitterInput = document.getElementById('editTwitter');
    editFacebookInput = document.getElementById('editFacebook');
    editYouTubeInput = document.getElementById('editYouTube');
    editLinkedInInput = document.getElementById('editLinkedIn');

    updateFooterContent();  // Call this first
    // updateSocialMediaLinks();  // Call this next
}

function updateTimingsContent() {

    const storedMondaySaturday = localStorage.getItem('footerMondaySaturday') || '';
    const storedSunday = localStorage.getItem('footerSunday') || '';

    document.getElementById('editMondaySaturdayContent').innerText = storedMondaySaturday;
    document.getElementById('editSundayContent').innerText = storedSunday;
}

function openEditTimingsDialog() {
  
    // Load existing data from local storage
    const storedMondaySaturday = localStorage.getItem('footerMondaySaturday');
    const storedSunday = localStorage.getItem('footerSunday');

    // Set the input values to the stored data
    editMondaySaturdayInput.value = storedMondaySaturday || '';
    editSundayInput.value = storedSunday || '';

    document.getElementById('editTimingsDialog').style.display = 'block';
}

function closeEditTimingsDialog() {
    document.getElementById('editTimingsDialog').style.display = 'none';
}

function saveEditTimingsDialog() {
    const editedMondaySaturday = editMondaySaturdayInput.value;
    const editedSunday = editSundayInput.value;

    // Save the edited data to local storage
    localStorage.setItem('footerMondaySaturday', editedMondaySaturday);
    localStorage.setItem('footerSunday', editedSunday);

    // Optionally, update the displayed content with the edited data
    updateTimingsContent();

    // Close the edit timings dialog
    closeEditTimingsDialog();
}

// function updateSocialMediaLinks() {
//     const storedTwitter = localStorage.getItem('footerTwitter') || '#';
//     const storedFacebook = localStorage.getItem('footerFacebook') || '#';
//     const storedYouTube = localStorage.getItem('footerYouTube') || '#';
//     const storedLinkedIn = localStorage.getItem('footerLinkedIn') || '#';

//     // Update the href attributes of the social media icons
//     document.getElementById('twitterIcon').href = storedTwitter;
//     document.getElementById('facebookIcon').href = storedFacebook;
//     document.getElementById('youtubeIcon').href = storedYouTube;
//     document.getElementById('linkedinIcon').href = storedLinkedIn;
// }

function updateFooterContent() {
    const storedAddress = localStorage.getItem('footerAddress') || '';
    const storedPhone = localStorage.getItem('footerPhone') || '';
    const storedEmail = localStorage.getItem('footerEmail') || '';

    // Update paragraph elements with stored data
    document.getElementById('editAddressParagraph').innerHTML = `<i class="fa fa-map-marker-alt me-3"></i>${storedAddress}`;
    document.getElementById('editPhoneParagraph').innerHTML = generateWhatsAppLink(storedPhone);
    document.getElementById('editEmailParagraph').innerHTML = generateEmailLink(storedEmail);
}

function generateWhatsAppLink(phoneNumber) {
    const formattedNumber = phoneNumber.replace(/\D/g, ''); // Remove non-numeric characters

    if (formattedNumber.length > 0) {
        // Display the WhatsApp link with white color
        return `<i class="fa fa-phone-alt me-3"></i><a href="https://wa.me/${formattedNumber}" target="_blank" style="color: white;">${formattedNumber}</a>`;
    } else {
        // If no number is entered, clear the WhatsApp link
        return `<i class="fa fa-phone-alt me-3"></i>`;
    }
}

function generateEmailLink(email) {
    if (email.length > 0) {
        // Display the email link with white color
        return `<i class="fa fa-envelope me-3"></i><a href="mailto:${email}" style="color: white;">${email}</a>`;
    } else {
        // If no email is entered, clear the email link
        return `<i class="fa fa-envelope me-3"></i>`;
    }
}

function openEditFooterDialog() {
    document.getElementById('editFooterDialog').style.display = 'block';

    initializeEditFooterInputs()
    // Load existing data from local storage
    const storedAddress = localStorage.getItem('footerAddress');
    const storedPhone = localStorage.getItem('footerPhone');
    const storedEmail = localStorage.getItem('footerEmail');
    // const storedTwitter = localStorage.getItem('footerTwitter');
    // const storedFacebook = localStorage.getItem('footerFacebook');
    // const storedYouTube = localStorage.getItem('footerYouTube');
    // const storedLinkedIn = localStorage.getItem('footerLinkedIn');

    // Set the input values to the stored data
    editAddressInput.value = storedAddress || '';
    editPhoneInput.value = storedPhone || '';
    editEmailInput.value = storedEmail || '';
    // editTwitterInput.value = storedTwitter || '';
    // editFacebookInput.value = storedFacebook || '';
    // editYouTubeInput.value = storedYouTube || '';
    // editLinkedInInput.value = storedLinkedIn || '';

}

function closeEditFooterDialog() {
    document.getElementById('editFooterDialog').style.display = 'none';
}
function saveEditFooterDialog() {
    const editedAddress = editAddressInput.value;
    const editedPhone = editPhoneInput.value;
    const editedEmail = editEmailInput.value;
    // const editedTwitter = editTwitterInput.value;
    // const editedFacebook = editFacebookInput.value;
    // const editedYouTube = editYouTubeInput.value;
    // const editedLinkedIn = editLinkedInInput.value;

    // Save the edited data to local storage
    localStorage.setItem('footerAddress', editedAddress);
    localStorage.setItem('footerPhone', editedPhone);
    localStorage.setItem('footerEmail', editedEmail);
    // localStorage.setItem('footerTwitter', editedTwitter);
    // localStorage.setItem('footerFacebook', editedFacebook);
    // localStorage.setItem('footerYouTube', editedYouTube);
    // localStorage.setItem('footerLinkedIn', editedLinkedIn);

    // Update the displayed content with the edited data
    updateFooterContent();

    // Update the social media links dynamically
    // updateSocialMediaLinks();

    // Create a clickable link for the saved address
    const mapsUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(editedAddress);
    document.getElementById('editAddressParagraph').innerHTML = '<i class="fa fa-map-marker-alt me-3"></i><a href="' + mapsUrl + '" target="_blank">' + editedAddress + '</a>';
    const whatsappUrl = 'https://wa.me/' + editedPhone;
    document.getElementById('editPhoneParagraph').innerHTML = '<i class="fa fa-phone-alt me-3"></i><a href="' + whatsappUrl + '" target="_blank">' + editedPhone + '</a>';
    // Create a clickable link for the saved email
    const mailtoUrl = 'mailto:' + editedEmail;
    document.getElementById('editEmailParagraph').innerHTML = '<i class="fa fa-envelope me-3"></i><a href="' + mailtoUrl + '">' + editedEmail + '</a>';

    // Close the edit footer dialog
    // Close the edit footer dialog
    closeEditFooterDialog();
}

// function openEditSocialMediaLinksMOdal(){
//     document.getElementById('editSocialMediaLinks').style.display='block'
//     initializeEditFooterInputs()
//     const storedTwitter = localStorage.getItem('footerTwitter');
//     const storedFacebook = localStorage.getItem('footerFacebook');
//     const storedYouTube = localStorage.getItem('footerYouTube');
//     const storedLinkedIn = localStorage.getItem('footerLinkedIn');

//     editTwitterInput.value = storedTwitter || '';
//     editFacebookInput.value = storedFacebook || '';
//     editYouTubeInput.value = storedYouTube || '';
//     editLinkedInInput.value = storedLinkedIn || '';

// }

// function closeEditSocialMediaLinksModal(){
//     document.getElementById('editSocialMediaLinks').style.display='none'
// }

// function saveSocialMediaLinks(){
//     const editedTwitter = editTwitterInput.value;
//     const editedFacebook = editFacebookInput.value;
//     const editedYouTube = editYouTubeInput.value;
//     const editedLinkedIn = editLinkedInInput.value;

//     localStorage.setItem('footerTwitter', editedTwitter);
//     localStorage.setItem('footerFacebook', editedFacebook);
//     localStorage.setItem('footerYouTube', editedYouTube);
//     localStorage.setItem('footerLinkedIn', editedLinkedIn);


//     updateSocialMediaLinks();

//     closeEditSocialMediaLinksModal()


// }


// Initialize edit timings inputs when the page loads
initializeEditTimingsInputs();

// Call this function when the page loads to populate the content from local storage
updateTimingsContent(

);

// Initialize edit footer inputs when the page loads
initializeEditFooterInputs();
