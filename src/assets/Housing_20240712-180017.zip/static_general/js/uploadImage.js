const localStorage = window.localStorage;

// Function to load the image from localStorage
function loadImageFromLocalStorage(imageId) {
    const savedImage = localStorage.getItem("uploadedImage_" + imageId);
    if (savedImage) {
        const imageElement = document.getElementById(imageId);
        imageElement.src = savedImage;
    }
}

// Initialize images when the page loadsdishModal
loadImageFromLocalStorage("img-to-change");
loadImageFromLocalStorage("brand_logo");
loadImageFromLocalStorage("imagetwo");
loadImageFromLocalStorage("imagetwo1");
loadImageFromLocalStorage("imagetwo2");
loadImageFromLocalStorage("imagetwo3");
loadImageFromLocalStorage("imagethree");
loadImageFromLocalStorage("imagefour");
loadImageFromLocalStorage("imagefive");
loadImageFromLocalStorage("imagesix");
loadImageFromLocalStorage("imageseven");
loadImageFromLocalStorage("imageeight");
loadImageFromLocalStorage("imagenine");
loadImageFromLocalStorage("imageten");
loadImageFromLocalStorage("imageeleven");
loadImageFromLocalStorage("imagetweleve");

// Function to remove the uploaded image from local storage
function removeImageFromLocalStorage(imageId) {
    localStorage.removeItem("uploadedImage_" + imageId);
}
// Call this function to remove the uploaded image for each image ID
removeImageFromLocalStorage("img-to-change");
removeImageFromLocalStorage("brand_logo");
removeImageFromLocalStorage("imagetwo");
removeImageFromLocalStorage("imagetwo1");
removeImageFromLocalStorage("imagetwo2");
removeImageFromLocalStorage("imagetwo3");
removeImageFromLocalStorage("imagethree");
removeImageFromLocalStorage("imagefour");
removeImageFromLocalStorage("imagefive");
removeImageFromLocalStorage("imagesix");
removeImageFromLocalStorage("imageseven");
removeImageFromLocalStorage("imageeight");
removeImageFromLocalStorage("imagenine");
removeImageFromLocalStorage("imageten");
removeImageFromLocalStorage("imageeleven");
removeImageFromLocalStorage("imagetweleve");

// Call this function when you want to remove the uploaded image
// For example, after removing the image from display or any other action
// You can call it like this:
// removeImageFromLocalStorage("img-to-change");

// Function to handle image upload for a specific image element
function uploadImage(imageId, inputId) {
    
    const imageInput = document.getElementById(inputId);
    const imageElement = document.getElementById(imageId);
    
    imageInput.addEventListener("change", (e) => {
        const file = e.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.onload = (e) => {
                const uploadedImage = e.target.result;
                imageElement.src = uploadedImage;

                // Store the uploaded image in localStorage
                localStorage.setItem("uploadedImage_" + imageId, uploadedImage);
            };

            reader.readAsDataURL(file);
            
        }
    });
    
    
    // Add change event listener to the input element
    imageInput.addEventListener('change', function() {
        const file = imageInput.files[0]; // Get the selected file
        
        // Display the file name in the edit card
        const fileNameDisplay = document.getElementById('fileNameDisplay');
        fileNameDisplay.textContent = file.name;
    });

// Trigger the input file dialog
    imageInput.click();
}

    
function uploadFile1(containerId, inputId) {
    const fileInput = document.getElementById(inputId);
    const container = document.getElementById(containerId);

    // Check if the container element exists
    if (container) {
        fileInput.addEventListener("change", (changeEvent) => {
            const file = changeEvent.target.files[0];

            if (file) {
                const reader = new FileReader();

                reader.onload = (loadEvent) => {
                    const uploadedFile = loadEvent.target.result;

                    if (file.type.startsWith('image/')) {
                        container.style.backgroundImage = 'url(' + uploadedFile + ')';
                        container.style.backgroundSize = 'cover';
                        container.innerHTML = '';
                    } else if (file.type.startsWith('video/')) {
                        const videoElement = document.createElement('video');
                        videoElement.src = uploadedFile;
                        videoElement.controls = true;
                        videoElement.style.width = '100%';
                        videoElement.style.height = '100%';
                        container.innerHTML = '';
                        container.appendChild(videoElement);
                    }

                    // Store the uploaded file in localStorage with a unique key
                    const localStorageKey = "uploadedFile_" + containerId;

                    try {
                        localStorage.setItem(localStorageKey, uploadedFile);
                        console.log(`Image stored successfully in ${localStorageKey}`);
                    } catch (error) {
                        console.error(`Failed to store image in ${localStorageKey}`, error);
                    }
                };

                reader.readAsDataURL(file);
            }
        });

        // Trigger the input file dialog
        fileInput.click();
    } else {
        console.error(`Element with ID '${containerId}' not found.`);
    }
}
