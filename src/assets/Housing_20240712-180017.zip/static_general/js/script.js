document.addEventListener('DOMContentLoaded', function () {
    // Get all delete buttons
    const deleteButtons = document.querySelectorAll('.delete-section');

    // Add event listener to each delete button
    deleteButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            // Get the ID of the section to delete from the data attribute
            const sectionId = this.dataset.targetSection;

            // Find the section by ID and remove it
            const sectionToDelete = document.getElementById(sectionId);
            if (sectionToDelete) {
                sectionToDelete.remove();
            } else {
                console.error("Section with ID " + sectionId + " not found.");
            }
        });
    });
});




document.addEventListener('DOMContentLoaded', function () {
    // Get all Wraper delete buttons
    const wrapperDeleteButtons = document.querySelectorAll('.wrapper-delete-btn');

    // Add event listener to each delete button
    wrapperDeleteButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const sectionId = this.dataset.targetSection;

            // Find the section by ID and remove it
            const sectionToDelete = document.getElementById(sectionId);
            if (sectionToDelete) {
                sectionToDelete.remove();
            } else {
                console.error("Section with ID " + sectionId + " not found.");
            }
        })
    })
})

document.addEventListener('DOMContentLoaded', function () {
    const hideButtons = document.querySelectorAll('.hide-btn');

    hideButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const sectionId = this.dataset.targetSection;

            // Find the section by ID and remove it
            const sectionToHide = document.getElementById(sectionId);
            if (sectionToHide.style.opacity === '0.2') {
                sectionToHide.style.opacity = '1';
            } else {
                sectionToHide.style.opacity = '0.2';
            }
            // sectionToHide.style.display='none'
        });
    });
});

// document.querySelector('.delete-btn').addEventListener('click', function () {
//     // Remove the whole section when the delete button is clicked
//     this.closest('.relative').remove();
// });

function addItem() {
    var featureContainer = document.getElementById("feature-container");
    var existingItem = featureContainer.querySelector('.flex.justify-evenly.items-center.gap-8:last-child');

    // Clone the existing item
    var newItem = existingItem.cloneNode(true);

    // Insert the new item as a sibling element next to the existing item
    existingItem.parentNode.insertBefore(newItem, existingItem.nextSibling);
}

function addServiceItem() {
    var ServiceContainer = document.getElementById("service-container");
    var existingItem = ServiceContainer.querySelector('.flex.flex-col.justify-center.items-center.gap-8:last-child');

    // Clone the existing item
    var newItem = existingItem.cloneNode(true);

    // Insert the new item as a sibling element next to the existing item
    existingItem.parentNode.insertBefore(newItem, existingItem.nextSibling);
}

// function addQuestionsItem() {
//     var questionContainer = document.getElementById("questions-container");
//     var existingItem = questionContainer.querySelector('.flex.flex-col.justify-center.items-center.gap-4.w-full:last-child');

//     // Clone the existing item
//     var newItem = existingItem.cloneNode(true);

//     // Insert the new item as a sibling element next to the existing item
//     existingItem.parentNode.insertBefore(newItem, existingItem.nextSibling);
// }






// 



// editor

// function openModal() {
//     document.getElementById("myModal").style.display = "block";
//   }

//   function closeModal() {
//     document.getElementById("myModal").style.display = "none";
//   }

//   function saveContent() {
//     var content = document.getElementById("editor").value;
//     // Handle saving the content
//     console.log("Content saved:", content);
//     // Close the modal
//     closeModal();
//   }

function openEditModal() {
    // Get the modal element
    var modal = document.getElementById("editModal");
    // Display the modal
    modal.style.display = "block";
}

// Function to close the edit modal
function closeEditModal() {
    // Get the modal element
    var modal = document.getElementById("editModal");
    // Hide the modal
    modal.style.display = "none";
}

// Function to save changes made in the edit modal
function saveEdit() {
    // Get the input values
    var menuTitleInput = document.getElementById("editHeadingInput").value;
    var popularItemsTitleInput = document.getElementById("editParaInput").value;
    // Update the text of the heading and paragraph elements
    document.getElementById("featureHeading1").innerText = menuTitleInput;
    document.getElementById("featurePara1").innerText = popularItemsTitleInput;
    // Close the modal after saving changes
    closeEditModal();
}

document.addEventListener("DOMContentLoaded", function () {
    openEditModal();

});

// function openKeywordModal() {
//     var modal = document.getElementById("keywordModal");
//     modal.style.display = "block";
// }

// function closeKeywordModal() {
//     var modal = document.getElementById("keywordModal");
//     modal.style.display = "none";
// }



function openKeywordModal(modalId) {
    var modal = document.querySelector("#" + modalId);
    if (modal) {
        modal.style.display = "block";
    } else {
        console.error("Modal with ID " + modalId + " not found.");
    }
}


function closeKeywordModal(modalId) {
    var modal = document.querySelector("#" + modalId);
    if (modal) {
        modal.style.display = "none";
    } else {
        console.error("Modal with ID " + modalId + " not found.");
    }
}

function generateAndCloseModal(modalId) {
    generatewithkey('landingText', 'landingTextKeywordInput', 'regenerate_landing_text');
    closeKeywordModal(modalId);
}

function generateFeatureInput1(modalId) {
    generateWithKeyword('item1', 'itempara1', 'keywordInput1')
    closeKeywordModal(modalId);
}

function generateFeatureInput2(modalId) {
    generateWithKeyword('item2', 'itempara2', 'keywordInput2')
    closeKeywordModal(modalId);
}

function generateFeatureInput3(modalId) {
    generateWithKeyword('item3', 'itempara3', 'keywordInput3')
    closeKeywordModal(modalId);
}
function generateFeatureInput4(modalId) {
    generateWithKeyword('item4', 'itempara4', 'keywordInput4')
    closeKeywordModal(modalId);
}
function generateFeatureInput5(modalId) {
    generateWithKeyword('item5', 'itempara5', 'keywordInput5')
    closeKeywordModal(modalId);
}
function generateFeatureInput6(modalId) {
    generateWithKeyword('item6', 'itempara6', 'keywordInput6')
    closeKeywordModal(modalId);
}
function generateFeatureInput7(modalId) {
    generateWithKeyword('item7', 'itempara7', 'keywordInput7')
    closeKeywordModal(modalId);
}
function generateFeatureInput8(modalId) {
    generateWithKeyword('item8', 'itempara8', 'keywordInput8')
    closeKeywordModal(modalId);
}
function generateFeatureInput9(modalId) {
    generateWithKeyword('item9', 'itempara9', 'keywordInput9')
    closeKeywordModal(modalId);
}
function generateFeatureInput10(modalId) {
    generateWithKeyword('item10', 'itempara10', 'keywordInput10')
    closeKeywordModal(modalId);
}



// services generate with comments input
function generateServiceInput1(modalId) {
    generateWithKeyword('itemHeading1', 'itemParagraph1', 'keywordInput_service1')
    closeKeywordModal(modalId);
}

function generateServiceInput2(modalId) {
    generateWithKeyword('itemHeading2', 'itemParagraph2', 'keywordInput_service2')
    closeKeywordModal(modalId);
}

function generateServiceInput3(modalId) {
    generateWithKeyword('itemHeading3', 'itemParagraph3', 'keywordInput_service3')
    closeKeywordModal(modalId);
}
function generateServiceInput4(modalId) {
    generateWithKeyword('itemHeading4', 'itemParagraph4', 'keywordInput_service4')
    closeKeywordModal(modalId);
}
function generateServiceInput5(modalId) {
    generateWithKeyword('itemHeading5', 'itemParagraph5', 'keywordInput_service5')
    closeKeywordModal(modalId);
}
function generateServiceInput6(modalId) {
    generateWithKeyword('itemHeading6', 'itemParagraph6', 'keywordInput_service6')
    closeKeywordModal(modalId);
}
function generateServiceInput7(modalId) {
    generateWithKeyword('itemHeading7', 'itemParagraph7', 'keywordInput_service7')
    closeKeywordModal(modalId);
}
function generateServiceInput8(modalId) {
    generateWithKeyword('itemHeading8', 'itemParagraph8', 'keywordInput_service8')
    closeKeywordModal(modalId);
}
function generateServiceInput9(modalId) {
    generateWithKeyword('itemHeading9', 'itemParagraph9', 'keywordInput_service9')
    closeKeywordModal(modalId);
}
function generateServiceInput10(modalId) {
    generateWithKeyword('itemHeading10', 'itemParagraph10', 'keywordInput_service10')
    closeKeywordModal(modalId);
}

// Smooth scrolling behavior
function scrollToSection(sectionId) {
    const target = document.getElementById(sectionId);
    if (target) {
        window.scrollTo({
            top: target.offsetTop,
            behavior: 'smooth'
        });
    }
}

// Optionally, prevent default action for all links with href="#"
document.querySelectorAll('a[href="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
    });
});


// Navbar responsiveness
// const hamburger = document.querySelector('.hamburger');
// const sidebar = document.querySelector('.sidebar');
// const closeBtn = document.querySelector('.close-btn');

// hamburger.addEventListener('click', () => {
//     sidebar.classList.toggle('hidden');
//     sidebar.classList.toggle('show-sidebar');
// });

// closeBtn.addEventListener('click', () => {
//     sidebar.classList.toggle('hidden');
//     sidebar.classList.toggle('show-sidebar');
// });

// function scrollToSection(sectionId) {
//     document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
// }

// function scrollToSection(sectionId) {
//     const section = document.getElementById(sectionId);
//     if (section) {
//         section.scrollIntoView({ behavior: 'smooth' });
//     }
// }


// Edit modal

let currentHeadingId = '';
let currentParagraphId = '';
let currentSingleHeadingId = '';

function showEditModal(headingId, paragraphId) {
    console.log("edit button script fetched")
    currentHeadingId = headingId;
    currentParagraphId = paragraphId;

    document.getElementById('editHeadingText').value = document.getElementById(headingId).innerText;
    document.getElementById('editParaText').value = document.getElementById(paragraphId).innerText;

    const headingColor = window.getComputedStyle(document.getElementById(headingId)).color;
    const paragraphColor = window.getComputedStyle(document.getElementById(paragraphId)).color;

    document.getElementById('headingColor').value = rgbToHex(headingColor);
    document.getElementById('paragraphColor').value = rgbToHex(paragraphColor);

    document.getElementById('editBookATable').style.display = 'block';
}

function rgbToHex(rgb) {
    if (rgb.startsWith('#')) return rgb;
    const [r, g, b] = rgb.match(/\d+/g);
    return "#" + ((1 << 24) + (parseInt(r) << 16) + (parseInt(g) << 8) + parseInt(b)).toString(16).slice(1);
}

function showSingleEditModal(SingleHeadingId) {
    currentSingleHeadingId = SingleHeadingId;

    const headingElement = document.getElementById(SingleHeadingId);
    document.getElementById('editSingleHeadingText').value = headingElement.innerText;

    // Set the current color in the color picker
    const currentColor = window.getComputedStyle(headingElement).color;
    document.getElementById('singleHeadingColor').value = rgbToHex(currentColor);

    document.getElementById('editSingleHeadingModal').style.display = 'block';
}


function hideEditBookATableModal() {
    document.getElementById('editBookATable').style.display = 'none';
}

function hideEditSingleHeadingModal() {
    document.getElementById('editSingleHeadingModal').style.display = 'none';
}

function updateContent() {
    const heading = document.getElementById('editHeadingText').value;
    const paragraph = document.getElementById('editParaText').value;
    const headingColor = document.getElementById('headingColor').value;
    const paragraphColor = document.getElementById('paragraphColor').value;

    document.getElementById(currentHeadingId).innerText = heading;
    document.getElementById(currentParagraphId).innerText = paragraph;

    // Update colors
    document.getElementById(currentHeadingId).style.color = headingColor;
    document.getElementById(currentParagraphId).style.color = paragraphColor;

    hideEditBookATableModal();
}

function updateSingleHeadingColor(color) {
    document.getElementById(currentSingleHeadingId).style.color = color;
}

function updateSingleHeadingContent() {
    const SingleHeading = document.getElementById('editSingleHeadingText').value;
    const headingColor = document.getElementById('singleHeadingColor').value;

    const headingElement = document.getElementById(currentSingleHeadingId);
    headingElement.innerText = SingleHeading;
    headingElement.style.color = headingColor;

    hideEditSingleHeadingModal();
}

function updateHeadingColor(color) {
    document.getElementById('editHeadingText').style.color = color;
}

function updateParagraphColor(color) {
    document.getElementById('editParaText').style.color = color;
}


function setFontStyle(fontStyle) {
    document.getElementById(currentHeadingId).style.fontFamily = fontStyle;
    document.getElementById(currentParagraphId).style.fontFamily = fontStyle;
}

function singlesetFontStyle(fontStyle) {
    document.getElementById(currentSingleHeadingId).style.fontFamily = fontStyle;
}

function setHeadingSize(size) {
    let fontSize;
    if (size === 'normal') {
        fontSize = '1.5em';
    } else if (size === 'small') {
        fontSize = '1em';
    } else if (size === 'large') {
        fontSize = '2.5em';
    }
    document.getElementById(currentHeadingId).style.fontSize = fontSize;
    document.getElementById(currentParagraphId).style.fontSize = fontSize;
}
function singlesetHeadingSize(size) {
    let fontSize;
    if (size === 'normal') {
        fontSize = '1.5em';
    } else if (size === 'small') {
        fontSize = '1em';
    } else if (size === 'large') {
        fontSize = '2.5em';
    }
    document.getElementById(currentSingleHeadingId).style.fontSize = fontSize;

}

function toggleBold() {
    const headingElement = document.getElementById(currentHeadingId);
    const paragraphElement = document.getElementById(currentParagraphId);

    // Always keep the heading bold
    headingElement.style.fontWeight = 'bold';

    // Toggle bold only for the paragraph
    paragraphElement.style.fontWeight = paragraphElement.style.fontWeight === 'bold' ? 'normal' : 'bold';

    // Update button appearance
    const boldButton = document.querySelector('[data-style="bold"]');
    boldButton.style.backgroundColor = paragraphElement.style.fontWeight === 'bold' ? 'rgba(0, 0, 0, 0.1)' : '';
}
function singletoggleBold() {
    const singleHeadingElement = document.getElementById(currentSingleHeadingId);
    singleHeadingElement.style.fontWeight = singleHeadingElement.style.fontWeight === '800' ? 'bold' : 'bold';
}

function toggleItalic() {
    const headingElement = document.getElementById(currentHeadingId);
    const paragraphElement = document.getElementById(currentParagraphId);
    headingElement.style.fontStyle = headingElement.style.fontStyle === 'italic' ? 'normal' : 'italic';
    paragraphElement.style.fontStyle = paragraphElement.style.fontStyle === 'italic' ? 'normal' : 'italic';
}
function singletoggleItalic() {

    const singleHeadingElement = document.getElementById(currentSingleHeadingId);
    singleHeadingElement.style.fontStyle = singleHeadingElement.style.fontStyle === 'italic' ? 'normal' : 'italic';
}

function toggleUnderline() {
    const headingElement = document.getElementById(currentHeadingId);
    const paragraphElement = document.getElementById(currentParagraphId);
    headingElement.style.textDecoration = headingElement.style.textDecoration === 'underline' ? 'none' : 'underline';
    paragraphElement.style.textDecoration = paragraphElement.style.textDecoration === 'underline' ? 'none' : 'underline';
}

function singletoggleUnderline() {
    const singleHeadingElement = document.getElementById(currentSingleHeadingId);
    singleHeadingElement.style.textDecoration = singleHeadingElement.style.textDecoration === 'underline' ? 'none' : 'underline';
}

function toggleStrikethrough() {
    const headingElement = document.getElementById(currentHeadingId);
    const paragraphElement = document.getElementById(currentParagraphId);
    headingElement.style.textDecoration = headingElement.style.textDecoration === 'line-through' ? 'none' : 'line-through';
    paragraphElement.style.textDecoration = paragraphElement.style.textDecoration === 'line-through' ? 'none' : 'line-through';
}
function singletoggleStrikethrough() {
    const singleHeadingElement = document.getElementById(currentSingleHeadingId);
    singleHeadingElement.style.textDecoration = singleHeadingElement.style.textDecoration === 'line-through' ? 'none' : 'line-through';
}

function toggleBulletList() {
    const paragraphElement = document.getElementById(currentParagraphId);
    const currentText = paragraphElement.innerText;
    if (currentText.startsWith('• ')) {
        paragraphElement.innerText = currentText.slice(2);
    } else {
        paragraphElement.innerText = '• ' + currentText;
    }
}

function toggleNumberedList() {
    const paragraphElement = document.getElementById(currentParagraphId);
    const currentText = paragraphElement.innerText;
    if (/^\d+\.\s/.test(currentText)) {
        paragraphElement.innerText = currentText.replace(/^\d+\.\s/, '');
    } else {
        paragraphElement.innerText = '1. ' + currentText;
    }
}



// Edit Testimonial

// Function to open the edit testimonial modal
function openEditTestimonialModal() {
    // Get the modal element


    // Get the current values of the titles
    // const editTestimonialTitleInput = document.getElementById("editTestimonialTitleInput");
    // const editTestimonialSubtitleInput = document.getElementById("editTestimonialSubtitleInput");
    // const editTestimonialPara1 = document.getElementById('editTestimonialPara1');
    // const editTestimonialPara2 = document.getElementById('editTestimonialPara2');
    // const editTestimonialPara3 = document.getElementById('editTestimonialPara3');
    // const editTestimonialPara4 = document.getElementById('editTestimonialPara4');

    // editTestimonialTitleInput.value = document.getElementById('editTestimonialTitle').textContent;
    // editTestimonialSubtitleInput.value = document.getElementById('editTestimonialSubtitle').textContent;
    // editTestimonialPara1.value = document.getElementById('testimonial-para-1').textContent;
    // editTestimonialPara2.value = document.getElementById('testimonial-para-2').textContent;
    // editTestimonialPara3.value = document.getElementById('testimonial-para-3').textContent;
    // editTestimonialPara4.value = document.getElementById('testimonial-para-4').textContent;
    // Set the current values to the input fields in the modal
    // Set the current section ID
    // currentAboutSection.value = 'testimonials';

    // Display the modal
    document.getElementById('editTestimonialModal').style.display = 'block';



    // Display the modal
    // modal.style.display = "block";
}

// Function to save the edits made in the testimonial modal
// function saveEditTestimonial() {
//     // Get the input values from the modal
//     const editTestimonialTitleInput = document.getElementById("editTestimonialTitleInput").value;
//     const editTestimonialSubtitleInput = document.getElementById("editTestimonialSubtitleInput").value;
//     const editTestimonialPara1 = document.getElementById('editTestimonialPara1').value;
//     const editTestimonialPara2 = document.getElementById('editTestimonialPara2').value;
//     const editTestimonialPara3 = document.getElementById('editTestimonialPara3').value;
//     const editTestimonialPara4 = document.getElementById('editTestimonialPara4').value;
//     // Update the titles on the page with the new values
//     document.getElementById("editTestimonialTitle").textContent = editTestimonialTitleInput;
//     document.getElementById("editTestimonialSubtitle").textContent = editTestimonialSubtitleInput;
//     document.getElementById('testimonial-para-1').textContent = editTestimonialPara1;
//     document.getElementById('testimonial-para-2').textContent = editTestimonialPara2;
//     document.getElementById('testimonial-para-3').textContent = editTestimonialPara3;
//     document.getElementById('testimonial-para-4').textContent = editTestimonialPara4;

//     localStorage.setItem('editTestimonialTitle', editTestimonialTitleInput);
//     localStorage.setItem('editTestimonialSubtitle', editTestimonialSubtitleInput);
//     localStorage.setItem('testimonial-para-1', editTestimonialPara1);
//     localStorage.setItem('testimonial-para-2', editTestimonialPara2);
//     localStorage.setItem('testimonial-para-3', editTestimonialPara3);
//     localStorage.setItem('testimonial-para-4', editTestimonialPara4);

//     // Close the modal after saving
//     closeEditTestimonialModal();
// }
// Wait for the DOM to be fully loaded

// Function to update the testimonial values
function saveEditTestimonial() {
    // Get the updated values from the input fields
    const editedTitle = document.getElementById('editTestimonialTitleInput').value;
    const editedSubtitle = document.getElementById('editTestimonialSubtitleInput').value;
    const editedPara1 = document.getElementById('editTestimonialPara1').value;
    const editedPara2 = document.getElementById('editTestimonialPara2').value;
    const editedPara3 = document.getElementById('editTestimonialPara3').value;
    const editedPara4 = document.getElementById('editTestimonialPara4').value;

    // Update the testimonial paragraphs
    document.getElementById('testimonial-para-1').textContent = editedPara1;
    document.getElementById('testimonial-para-2').textContent = editedPara2;
    document.getElementById('testimonial-para-3').textContent = editedPara3;
    document.getElementById('testimonial-para-4').textContent = editedPara4;

    // Close the modal
    closeEditTestimonialModal();

    // Update the testimonial paragraphs again after the modal is closed
    updateTestimonialParagraphs();
}
function updateTestimonialParagraphs() {
    const editedPara1 = document.getElementById('editTestimonialPara1').value;
    const editedPara2 = document.getElementById('editTestimonialPara2').value;
    const editedPara3 = document.getElementById('editTestimonialPara3').value;
    const editedPara4 = document.getElementById('editTestimonialPara4').value;

    const testimonialItems = document.querySelectorAll('.testimonial-item');
    if (testimonialItems.length === 4) {
        testimonialItems[0].querySelector('.editable-text').innerHTML = editedPara1;
        testimonialItems[1].querySelector('.editable-text').innerHTML = editedPara2;
        testimonialItems[2].querySelector('.editable-text').innerHTML = editedPara3;
        testimonialItems[3].querySelector('.editable-text').innerHTML = editedPara4;
    }
}



// Function to close the edit testimonial modal
function closeEditTestimonialModal() {
    // Get the modal element
    document.getElementById('editTestimonialModal').style.display = 'none';
}

// Function to toggle text style (you provided this function earlier)
function toggleTextStyle(elementId, element) {
    // You can customize this function based on your requirements
    // For now, let's just log the element content when the user types
    // console.log(`Text in ${elementId}: ${element.innerText}`);
}

// call to action (enquire now)

let updatedWhatsAppNumber = "your_default_whatsapp_number";

function openEditCallToActionModal() {
    document.getElementById('editCallToActionModal').style.display = 'block';
}


function hideEditCallToActionModal() {
    document.getElementById('editCallToActionModal').style.display = 'none';
}

function openEditCallToActionModal2() {
    document.getElementById('editCallToActionModal2').style.display = 'block';
}

function hideEditCallToActionModal2() {
    document.getElementById('editCallToActionModal2').style.display = 'none';
}

function showEditButton(show) {
    document.getElementById('editButtonWrapper').style.display = show ? 'inline-block' : 'none';
}

function updateBookATableNumber() {
    const callToActionButtonText = document.getElementById('editCallToActionButtonText').value;
    const editCallToActionNumber = document.getElementById('editCallToActionNumber').value;

    // Update the WhatsApp number
    updatedWhatsAppNumber = editCallToActionNumber;

    // Update the text of the button
    document.getElementById('callToActionButton').textContent = callToActionButtonText;

    hideEditCallToActionModal();
}

function updateBookATableNumber2() {
    const callToActionButtonText = document.getElementById('editCallToActionButtonText2').value;

    // Update the WhatsApp number
    updatedWhatsAppNumber = editCallToActionNumber;

    // Update the text of the button
    document.getElementById('callToActionButton2').textContent = callToActionButtonText;

    hideEditCallToActionModal2();
}


function openCallToActionWhatsApp() {
    window.open('https://wa.me/' + updatedWhatsAppNumber, '_blank');
}

// // Footer section
// function openEditCompnayDialog() {
//     var modal = document.getElementById("editCompanyDialog");
//     modal.style.display = "block";
// }
// function closeEditCompanyDialog() {
//     var modal = document.getElementById("editCompanyDialog");
//     modal.style.display = "none";
// }

// function saveCompanyChanges() {
//     const editCompanyName = document.getElementById('editCompanyName').value;
//     const editHomeLink = document.getElementById('editHomeLink').value;
//     const editAboutUsLink = document.getElementById('editAboutUsLink').value;
//     const editOurServicesLink = document.getElementById('editOurServicesLink').value;
//     const editOurWorkLink = document.getElementById('editOurWorkLink').value;
//     const editContactUsLink = document.getElementById('editContactUsLink').value;

//     // Update Company Name
//     document.getElementById('companyNameFooter').innerText = editCompanyName;

//     // Update Home Link
//     document.getElementById('HomeLink').innerText = editHomeLink;

//     // Update About Us Link
//     document.getElementById('AboutUsLink').innerText = editAboutUsLink;

//     // Update Our Services Link
//     document.getElementById('OurServicesLink').innerText = editOurServicesLink;

//     // Update Our Work Link
//     document.getElementById('OurWorkLink').innerText = editOurWorkLink;

//     // Update Contact Us Link
//     document.getElementById('ContactUsLink').innerText = editContactUsLink;

//     // Close the modal
//     closeEditCompanyDialog();
// }

// Footer whatsapp section

function editWhatsapp() {
    document.getElementById('editWhatsapp').style.display = 'block';
}

function closeEditWhatsApp() {
    var modal = document.getElementById("editWhatsapp");
    modal.style.display = "none";
}


// Function to update headings and WhatsApp number
function updateContactInfoWa() {
    // Get values from the modal inputs
    const newWhatsAppNumber = document.getElementById('editWhatsAppNumber').value;

    // Update the headings and WhatsApp number

    document.getElementById('contactUsButtonFooter').setAttribute('onclick', 'openWhatsApp("' + newWhatsAppNumber + '")');

    const editContactUs = document.getElementById('editContactUs').value;
    document.getElementById('contactUsButtonFooter').textContent = editContactUs;
    localStorage.setItem('contactUsButtonFooter', editContactUs);

    // const editWhatsappUsHeading = document.getElementById('editWhatsappUs').value;
    // document.getElementById('editWhatsappUsHeading').textContent = editWhatsappUsHeading;
    // localStorage.setItem('editWhatsappUsHeading', editWhatsappUsHeading);


    // Close the modal
    closeEditWhatsApp();
}

// Function to open WhatsApp Business contact page
function openWhatsApp(whatsappNumber) {
    window.open('https://wa.me/' + whatsappNumber, '_blank');
}


// for logo 
document.getElementById('image_input_logo').addEventListener('change', function (event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            const brandLogoImg = document.getElementById('brand_logo_img');
            const brandLogoText = document.getElementById('brand_logo_text');

            brandLogoImg.src = e.target.result;
            brandLogoImg.classList.remove('hidden');
            brandLogoText.classList.add('hidden');
        };
        reader.readAsDataURL(file);
    }
});

// navbar edit with data-target show and hover can be applied to everthing for showing the button on hover if problemed
document.addEventListener('DOMContentLoaded', function () {
    const hoverTargets = document.querySelectorAll('[data-hover-target]');

    hoverTargets.forEach(target => {
        const targetId = target.getAttribute('data-hover-target');
        const showElement = document.querySelector(`[data-hover-show="${targetId}"]`);

        if (showElement) {
            target.addEventListener('mouseenter', () => {
                showElement.style.opacity = '1';
                if (showElement.classList.contains('hidden')) {
                    showElement.classList.remove('hidden');
                }
            });

            target.addEventListener('mouseleave', () => {
                showElement.style.opacity = '0';
                if (targetId.includes('upload-button')) {
                    setTimeout(() => {
                        showElement.classList.add('hidden');
                    }, 300); // Match this with your transition duration
                }
            });
        }
    });
});


// log in sign up form logic

function showToast(message, type = 'info', duration = 5000) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icon = document.createElement('i');
    icon.className = 'toast-icon';
    switch (type) {
        case 'success':
            icon.textContent = '✓';
            break;
        case 'error':
            icon.textContent = '✕';
            break;
        case 'warning':
            icon.textContent = '!';
            break;
        default:
            icon.textContent = 'i';
    }

    const messageSpan = document.createElement('span');
    messageSpan.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(messageSpan);
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 100);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, duration);
}

document.getElementById('loginFormElement').addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(event.target);
    const response = await fetch('/login', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    if (response.ok) {
        showToast('Logged in successfully', 'success');
        console.log("Logged in successfully", data);
        // Redirect to the dashboard page after successful login
        setTimeout(() => {
            window.location.href = '/dashboard';
        }, 1000);
    } else {
        showToast("Wrong User Email or Password!!", 'error');
        console.log("Error in logging in", data.message);
    }
});

document.getElementById('signupFormElement').addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(event.target);

    // Show loader
    document.getElementById('loader').classList.remove('hidden');

    try {
        // First, request email verification
        const verificationResponse = await fetch('/request_verification', {
            method: 'POST',
            body: JSON.stringify({ email: formData.get('signupEmail') }),
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const verificationData = await verificationResponse.json();

        // Hide loader
        document.getElementById('loader').classList.add('hidden');

        if (verificationResponse.ok) {
            // Show verification modal
            document.getElementById('verificationModal').classList.remove('hidden');

            // Set up verification code input fields
            const codeInputs = document.querySelectorAll('.verification-code-input');
            codeInputs.forEach((input, index) => {
                input.addEventListener('input', (e) => {
                    if (e.target.value.length === 1) {
                        if (index < codeInputs.length - 1) {
                            codeInputs[index + 1].focus();
                        }
                    }
                });

                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && index > 0 && input.value.length === 0) {
                        codeInputs[index - 1].focus();
                    }
                });
            });

            // Handle verification code submission
            document.getElementById('verifyCodeBtn').addEventListener('click', async () => {
                const verificationCode = Array.from(codeInputs).map(input => input.value).join('');
                if (verificationCode.length === 4) {
                    // Show loader again
                    document.getElementById('loader').classList.remove('hidden');

                    try {
                        // Verify the code
                        const verifyResponse = await fetch('/verify_code', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                email: formData.get('signupEmail'),
                                code: verificationCode
                            })
                        });

                        const verifyData = await verifyResponse.json();

                        if (verifyResponse.ok) {
                            // Code is correct, proceed with signup
                            formData.append('verificationCode', verificationCode);
                            const signupResponse = await fetch('/signup', {
                                method: 'POST',
                                body: formData
                            });

                            const signupData = await signupResponse.json();

                            if (signupResponse.ok) {
                                showToast('Registration successful! You can now sign in.', 'success');
                                console.log("Registration successful", signupData);
                                document.getElementById('signupForm').classList.add('hidden');
                                document.getElementById('loginForm').classList.remove('hidden');
                                document.getElementById('verificationModal').classList.add('hidden');
                            } else {
                                showToast('Error: ' + signupData.message, 'error');
                                console.log("Error in registration", signupData.message);
                            }
                        } else {
                            showToast('Error: ' + verifyData.message, 'error');
                            console.log("Error in verification", verifyData.message);
                        }
                    } finally {
                        // Hide loader
                        document.getElementById('loader').classList.add('hidden');
                    }
                } else {
                    showToast('Please enter all 4 digits of the verification code.', 'warning');
                }
            });
        } else {
            showToast('Error: ' + verificationData.message, 'error');
            console.log("Error in verification request", verificationData.message);
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('An unexpected error occurred. Please try again.', 'error');
    } finally {
        // Ensure loader is hidden in case of any errors
        document.getElementById('loader').classList.add('hidden');
    }
});

// Close verification modal if user clicks outside of it
document.getElementById('verificationModal').addEventListener('click', (event) => {
    if (event.target === event.currentTarget) {
        event.target.classList.add('hidden');
    }
});

document.getElementById('goLiveBtn').addEventListener('click', async function () {
    try {
        const response = await fetch('/dashboard');
        if (response.ok) {
            // const html = await response.text();
            // Replace the current page content with the dashboard template
            window.location.href = "/dashboard";
        } else {
            // User is not logged in, show the authentication modal
            document.getElementById('authModal').style.display = 'flex';
            document.getElementById('loginForm').classList.remove('hidden');
            document.getElementById('signupForm').classList.add('hidden');
        }
    } catch (error) {
        console.error('Error:', error);
    }

});

document.getElementById('showSignup').addEventListener('click', function () {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('signupForm').classList.remove('hidden');
});

document.getElementById('showLogin').addEventListener('click', function () {
    document.getElementById('signupForm').classList.add('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
});

window.onclick = function (event) {
    if (event.target == document.getElementById('authModal')) {
        document.getElementById('authModal').style.display = 'none';
    }
}

