        function openEditModal(titleId, amountId, descriptionId) {
        const titleElement = document.getElementById(titleId);
        const amountElement = document.getElementById(amountId);
        const descriptionElement = document.getElementById(descriptionId);

        const editTitle = document.getElementById('editDishTitle');
        const editAmount = document.getElementById('editDishAmount');
        const editDescription = document.getElementById('editDishDescription');
        const currentSection = document.getElementById('currentSection');

        // Set the current content in the modal input fields
        editTitle.value = titleElement.innerText;
        editAmount.value = amountElement.innerText;
        editDescription.value = descriptionElement.innerText;

        // Set the current section ID
        currentSection.value = titleId;

        // Display the modal
        document.getElementById('dishModal').style.display = 'block';
    }

    function saveDishEdit() {
        const editTitle = document.getElementById('editDishTitle');
        const editAmount = document.getElementById('editDishAmount');
        const editDescription = document.getElementById('editDishDescription');
        const sectionId = document.getElementById('currentSection').value;

        // Update the content in the dish information
        const titleElement = document.getElementById(sectionId);
        const amountElement = document.getElementById(sectionId.replace('Title', 'Amount'));
        const descriptionElement = document.getElementById(sectionId.replace('Title', 'Description'));

        titleElement.innerText = editTitle.value;
        amountElement.innerText = editAmount.value;
        descriptionElement.innerText = editDescription.value;

        // Save the edited content to local storage
        localStorage.setItem(sectionId, editTitle.value);
        localStorage.setItem(sectionId.replace('Title', 'Amount'), editAmount.value);
        localStorage.setItem(sectionId.replace('Title', 'Description'), editDescription.value);

        // Close the modal
        document.getElementById('dishModal').style.display = 'none';
    }

    function closeEditModal() {
        document.getElementById('dishModal').style.display = 'none';
    }
        
    // function moveSection(sectionId, direction) {
    //     const section = document.getElementById(sectionId);
    //     const container = section.parentElement;
    //     const index = Array.from(container.children).indexOf(section);
    //     // const index =1;
    
    //     if (direction === 'up' && index >= 0) {
    //         container.insertBefore(section, container.children[index - 1]);
    //     }
    
    //     if (direction === 'down' && index < container.children.length - 1) {
    //         container.insertBefore(container.children[index + 1], section);
    //     }
    // }

    function moveSection(sectionId, direction) {
        const section = document.getElementById(sectionId);
        if (!section) return;
    
        if (direction === 'up') {
            const prevSection = section.previousElementSibling;
            if (prevSection) {
                section.parentNode.insertBefore(section, prevSection);
                console.log("up button clicked")
            }
        } else if (direction === 'down') {
            const nextSection = section.nextElementSibling;
            if (nextSection) {
                section.parentNode.insertBefore(nextSection, section);
                section.parentNode.insertBefore(section, nextSection.nextElementSibling);
                console.log("down button clicked")
            }
        }
    }
    
    // Function to handle drag start event
    function handleDragStart(e) {
        // Set the data being dragged (in this case, the section's ID)
        e.dataTransfer.setData('text/plain', e.target.id);
    }
    
    // Prevent default behavior to enable dropping
    document.addEventListener('dragover', function (e) {
        e.preventDefault();
    });
    
    // Function to handle drop event
    document.addEventListener('drop', function (e) {
        e.preventDefault();
    
        const draggedId = e.dataTransfer.getData('text/plain');
        const draggedElement = document.getElementById(draggedId);
    
        // If the drop target is a valid container, append the dragged element
        if (e.target.classList.contains('container-xxl')) {
            e.target.appendChild(draggedElement);
        }
    });
    