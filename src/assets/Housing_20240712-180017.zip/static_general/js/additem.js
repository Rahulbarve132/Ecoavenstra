let itemCount = 9; // Counter to keep track of item IDs

function addItem() {
    // Send a POST request to the server to add a new item
    fetch('/add_item', {
        method: 'POST',

    })
        .then(response => response.json())
        .then(newData => {
            itemCount++; // Increment the item counter

            // Create a new template of the item
            const newItem = document.createElement('div');
            newItem.classList.add('col-lg-6'); // Add Bootstrap grid class
            newItem.id = `dishDetails${itemCount}`; // Set unique ID for the new item

            // Construct the inner HTML of the new item
            newItem.innerHTML = `
                <div class="d-flex align-items-center menu-item__listing">
                    <img class="flex-shrink-0 img-fluid rounded" src="${newData.image}" alt="" style="width: 80px; height: 60px;" id="image${itemCount}">
                    <input type="file" id="image_input${itemCount}" accept="image/png, image/jpeg" style="display: none;">
                    <div class="w-100 d-flex flex-column text-start ps-4">
                        <h5 class="d-flex justify-content-between border-bottom pb-2">
                            <span id="dishTitle${itemCount}">${newData.dish_title}</span>
                            <span class="text-primary" id="dishAmount${itemCount}">${newData.dish_amount}</span>
                            <button class="btn btn-secondary" onclick="openEditMenuItemModal(${itemCount}, 'image${itemCount}', 'image_input${itemCount}')">Edit</button>
                            <button class="btn btn-danger bg-transparent" onclick="deleteTab('dishDetails${itemCount}')">
                                <i class="material-icons" style="color: black;">delete</i>
                            </button>
                        </h5>
                        <button id="button${itemCount}" class="btn btn-primary" onclick="regenerateDishTitleAndDescription('dishTitle${itemCount}', 'dishDescription${itemCount}')">Regenerate Dish</button>
                        <small class="fst-italic" id="dishDescription${itemCount}">${newData.dish_description}</small>
                    </div>
                </div>
            `;

            // Append the new item to the container
            document.querySelector(".tab-content .row").appendChild(newItem);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



// function addItemToService() {
//     // Send a POST request to the server to add a new service item
//     fetch('/add_item', {
//         method: 'POST'
//     })
//         .then(response => response.json())
//         .then(newData => {
//             count++; // Increment the item counter

//             // Create a new template of the service item
//             const newServiceItem = document.createElement('div');
//             // newServiceItem.classList.add('col-lg-3', 'col-sm-6', 'wow', 'fadeInUp');
//             newServiceItem.classList.add('grid', 'lg:grid-cols-3', 'justify-items-center', 'items-center', 'w-[70%]', 'my-12', 'gap-12');
//             // newServiceItem.setAttribute('data-wow-delay', '0.1s');
//             // newServiceItem.style.visibility = 'hidden';
//             newServiceItem.style.animationDelay = '0.1s';
//             newServiceItem.style.animationName = 'none';
//             newServiceItem.id = `serviceItem${count}`;

//             // Construct the inner HTML of the new service item
//             // newServiceItem.innerHTML = `
//             //     <div class="service-item flex flex-col justify-center items-center gap-8">
//             //         <div class="p-4 service-head-container-1">
//             //             <i class="fa fa-3x fa-user-tie text-primary mb-4 head-container-1"></i>

//             //             <button class="edit-button2 inline-button" onclick="openEditDialog('item${count}')">Edit</button>
//             //             <button id="regenerateButton${count}" onclick="regenerateserviceTitleandDescription('item${count}', 'itempara${count}')">Regenerate</button>

//             //             <h5 id="item${count}" class="editable-text" contenteditable="true" oninput="toggleTextStyle('item${count}', this)">${newData.service_title}</h5>
//             //             <p id="itempara${count}" class="editable-para" contenteditable="true" oninput="toggleTextStyle('itempara${count}', this)">${newData.service_description}</p>
//             //             <button class="btn btn-danger bg-transparent" onclick="deleteTab('service${count}')">
//             //                 <i class="material-icons" style="color: black;">delete</i>
//             //             </button>
//             //         </div>
//             //     </div>
//             // `;

//             newServiceItem.innerHTML = `
//         <div class="grid lg:grid-cols-3 justify-items-center items-center w-[70%] my-12 gap-12"
//             <div class="service-item flex flex-col justify-center items-center gap-8">

//                     <div class="image-wrapper relative w-[70%] h-[220px]">
//                         <img class=" h-full w-[450px] " src="${newData.service_image_0}" alt="" id="imagethree">
//                         <input type="file" id="image_input5" accept="image/png, image/jpeg" style="display: none;">
//                         <div
//                             class="upload-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2  space-x-4 p-2 hidden transition-all duration-300 bg-blue-500 rounded-lg">
//                             <button id="button3" class="text-slate-100   focus:outline-none"
//                                 onclick="uploadImage('imagethree','image_input5')">
//                                 <span class="material-icons">upload</span>
//                                 <span class="tooltip-text">Upload Image</span>
//                             </button>
//                         </div>
//                     </div>


//                     <div class=" relative flex-col justify-center items-center gap-4  ">
//                     <div class="absolute transform z-10 w-full h-full hidden delete-button-wrapper ">


//                         <div
//                             class="flex justify-center items-center space-x-4 p-2 heading-buttons transition-all duration-300 bg-blue-500 rounded-lg  m-auto">
//                             <button class="text-slate-100 hover:text-red-600 focus:outline-none regenerate-btn"
//                                 id="regenerateButton4"
//                                 onclick="regenerateserviceTitleandDescription('itemHeading${count}', 'itemParagraph${count}')">
//                                 <span class="material-icons">refresh</span>
//                                 <span class="button-text">Regenerate</span>
//                             </button>

//                             <button class="text-slate-100 hover:text-blue-600 focus:outline-none regenerate-ai-btn"
//                                 onclick="openKeywordModal('serviceKeywordInput${count}')">
//                                 <span class="material-icons">chat</span>
//                                 <span class="button-text">Regenerate with Comments</span>
//                             </button>
//                             <button class="text-slate-100 hover:text-yellow-600 focus:outline-none edit-btn"
//                                 id="button5" class="edit-button2" onclick="showEditModal('itemHeading${count}','itemParagraph${count}')">
//                                 <span class="material-icons">edit</span>
//                                 <span class="button-text">Edit Text</span>
//                             </button>
//                         </div>

//                         <button
//                             class=" absolute top-0 right-0 hover:text-red-600 focus:outline-none wrapper-delete-btn"
//                             data-target-section="serviceItem${count}">
//                             <span class="material-icons">delete</span>
//                         </button>
//                     </div>

//                     <div class="flex flex-col gap-4 justify-center items-center content-wrapper">
//                         <h1 id="itemHeading${count}" class="font-semibold text-3xl text-center editable-text">
//                             ${newData.service_title}</h1>
//                         <p id="itemParagraph${count}" class="text-center text-gray-500 editable-para">
//                             ${newData.service_description}</p>



//                     </div>


//                     <div class="absolute top-0 left-0 w-full h-full hover:delete-button-wrapper"></div>
//                 </div>

//                 <div id="serviceKeywordInput${count}" class="keywordmodal">
//                 <div class="keywordmodal-content">
//                     <span class="keywordModalClose"
//                         onclick="closeKeywordModal('serviceKeywordInput${count}')">&times;</span>
//                     <input type="text" id="keywordInput_service${count}" placeholder="Enter keyword">
//                     <button id="keywordButton_service${count}"
//                         onclick=" generateServiceInput1('serviceKeywordInput${count}')">button1</button>
//                 </div>
//             </div>
//         </div>


//             `

//             // Append the new service item to the container
//             document.getElementById("service-container").appendChild(newServiceItem);
//         })
//         .catch(error => {
//             console.error('Error:', error);
//         });
// }


let count = 3; // Counter to keep track of item IDs


function addItemToService() {
    // Send a POST request to the server to add a new service item
    fetch('/add_item', {
        method: 'POST'
    })
        .then(response => response.json())
        .then(newData => {
            count++; // Increment the item counter

            // Create a new template of the service item
            const newServiceItem = document.createElement('div');
            // newServiceItem.classList.add('grid', 'lg:grid-cols-3', 'justify-items-center', 'items-center', 'w-[70%]', 'my-12', 'gap-12', 'outline');
            newServiceItem.classList.add('service-items', 'flex', 'justify-center', 'items-center', 'gap-8');
            newServiceItem.style.animationDelay = '0.1s';
            newServiceItem.style.animationName = 'none';
            newServiceItem.id = `serviceItem${count}`;

            // Construct the inner HTML of the new service item
            newServiceItem.innerHTML = `
            <div class="service-item flex flex-col justify-center items-center gap-8 h-[500px] w-full">
                <div class="image-wrapper relative w-[70%] h-[220px] rounded-xl shadow-lg transition duration-300 hover:scale-105 ">
                    <img class="h-full w-[450px]" src="${newData.image}" alt="" id="imagethree${count}">
                    <input type="file" id="image_input${count}" accept="image/png, image/jpeg" style="display: none;">
                    <div class="upload-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 space-x-4 p-2 hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">
                        <button id="button${count}" class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded" onclick="uploadImage('imagethree${count}', 'image_input${count}')">
                            <span class="material-icons">upload</span>
                            <span class="tooltip-text">Upload Image</span>
                        </button>
                    </div>
                </div>

                <div class="relative flex-col justify-center items-center gap-4 ">
                    <div class="absolute transform z-10 w-full h-full hidden delete-button-wrapper">
                        <div class="flex justify-center items-center space-x-4 p-2 heading-buttons transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg m-auto">
                            <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded regenerate-btn" id="regenerateButton${count}" onclick="regenerateserviceTitleandDescription('itemHeading${count}', 'itemParagraph${count}')">
                                <span class="material-icons">sync</span>
                                <span class="button-text">Regenerate</span>
                            </button>
                            <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded regenerate-ai-btn" onclick="openKeywordModal('serviceKeywordInput${count}')">
                                <span class="material-icons">feedback</span>
                                <span class="button-text">Regenerate with Comments</span>
                            </button>
                            <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded edit-btn" id="button${count}" class="edit-button2" onclick="showEditModal('itemHeading${count}','itemParagraph${count}')">
                                <span class="material-icons">create</span>
                                <span class="button-text">Edit Text</span>
                            </button>
                            <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded wrapper-delete-btn" data-target-section="serviceItem${count}">
                            <span class="material-icons">delete</span>
                            <span class="button-text">Delete Item</span>
                        </button>
                        </div>
   
                    </div>

                    <div class="flex flex-col gap-4 justify-center items-center content-wrapper">
                        <h1 id="itemHeading${count}" class="font-semibold text-2xl text-center editable-text">${newData.service_title}</h1>
                        <p id="itemParagraph${count}" class="text-center text-gray-500 editable-para">${newData.service_description}</p>
                    </div>

                    <div class="absolute top-0 left-0 w-full h-full hover:delete-button-wrapper"></div>
                </div>

                <div id="serviceKeywordInput${count}" class="keywordmodal">
                    <div class="keywordmodal-content">
                        <span class="keywordModalClose" onclick="closeKeywordModal('serviceKeywordInput${count}')">&times;</span>
                        <input type="text" id="keywordInput_service${count}" placeholder="Enter keyword">
                        <button id="keywordButton_service${count}" onclick="generateServiceInput${count}('serviceKeywordInput${count}')">button${count}</button>
                    </div>
                </div>
            </div>
        `;

            // Append the new service item to the container
            document.getElementById("service-container").appendChild(newServiceItem);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function uploadImage(imgId, inputId) {
    const imageInput = document.getElementById(inputId);
    imageInput.click();
    imageInput.addEventListener('change', () => {
        const file = imageInput.files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById(imgId).src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}

let featureCount = 3;
function addItemToFeature() {
    // Send a POST request to the server to add a new feature item
    fetch('/add_item', {
        method: 'POST'
    })
        .then(response => response.json())
        .then(data => {
            featureCount++; // Increment the item counter
            console.log(data);

            // Create a new template of the feature item
            const newFeatureItem = document.createElement('div');
            if (featureCount % 2 === 0) {
                newFeatureItem.classList.add('flex', 'flex-col-reverse', 'lg:flex-row-reverse', 'justify-evenly', 'items-center', 'gap-8','rounded-xl', 'p-4', 'transition', 'duration-300' ,'hover:scale-105');
            } else {
                newFeatureItem.classList.add('flex', 'flex-col-reverse', 'lg:flex-row', 'justify-evenly', 'items-center', 'gap-8','rounded-xl', 'p-4', 'transition', 'duration-300' ,'hover:scale-105');
            }
            newFeatureItem.id = `featureItem${featureCount}`;

            // Construct the inner HTML of the new feature item
            newFeatureItem.innerHTML = `
            <div class="relative flex-col justify-center items-center gap-4 w-[80%] lg:w-[50%]">
                <!-- Wrapper div for buttons -->
                <div class="absolute transform z-10 w-full h-full hidden delete-button-wrapper">
                    <!-- Other buttons -->
                    <div class="flex justify-center items-center space-x-4 p-2 heading-buttons transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg m-auto">
                        <!-- regenerate button -->
                        <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none regenerate-btn p-1 rounded" id="regenerateButton${featureCount}" onclick="regeneratefeatureTitleandDescription('item${featureCount}', 'itempara${featureCount}')">
                            <span class="material-icons">sync</span>
                            <span class="button-text">Regenerate</span>
                        </button>
                        <!-- regenerate with Comments button -->
                        <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none regenerate-ai-btn p-1 rounded" onclick="openKeywordModal('featureKeywordInput${featureCount}')">
                            <span class="material-icons">feedback</span>
                            <span class="button-text">Regenerate with Comments</span>
                        </button>
                        <!-- Edit button -->
                        <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" onclick="showEditModal('item${featureCount}','itempara${featureCount}')">
                            <span class="material-icons">create</span>
                            <span class="button-text">Edit Text</span>
                        </button>
                        <!-- Delete button -->
                    <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded" data-target-section="featureItem${featureCount}">
                        <span class="material-icons">delete</span>
                        <span class="button-text">Delete Item</span>
                    </button>
                    </div>
                   
                </div>
                <div class="flex flex-col gap-4">
                    <h1 class="font-semibold text-3xl text-center" id="item${featureCount}">${data.service_title}</h1>
                    <p class="text-gray-700 text-center" id="itempara${featureCount}">${data.service_description}</p>
                </div>
                <!-- Hover trigger for showing the wrapper div -->
                <div class="absolute top-0 left-0 w-full h-full hover:delete-button-wrapper"></div>
            </div>
            <div class="image-wrapper relative w-[80%] sm:h-[300px] md:h-[400px] h-[200px] lg:w-[300px] lg:h-[350px]">
                <img class="w-full h-full rounded-xl" src="${data.image}" alt="" id="imageFeature${featureCount}">
                <input type="file" id="image_input_feature${featureCount}" accept="image/png, image/jpeg" style="display: none;">
                <div class="upload-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 space-x-4 p-2 hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">
                    <button id="button${featureCount}" class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded" onclick="uploadImage('imageFeature${featureCount}', 'image_input_feature${featureCount}')">
                        <span class="material-icons">upload</span>
                        <span class="tooltip-text">Upload Image</span>
                    </button>
                </div>
            </div>
            <div id="featureKeywordInput${featureCount}" class="keywordmodal">
                <div class="keywordmodal-content">
                    <span class="keywordModalClose" onclick="closeKeywordModal('featureKeywordInput${featureCount}')">&times;</span>
                    <input type="text" id="keywordInput_feature${featureCount}" placeholder="Enter keyword">
                    <button id="keywordButton_feature${featureCount}" onclick="generateFeatureInput${featureCount}('featureKeywordInput${featureCount}')">button${featureCount}</button>
                </div>
            </div>
        `;

            // Append the new feature item to the container
            document.getElementById("feature-container").appendChild(newFeatureItem);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

let teamCount = 3;
function addItemToTeams() {
    // Send a POST request to the server to add a new team item
    fetch('/add_item', {
        method: 'POST'
    })
        .then(response => response.json())
        .then(data => {
            teamCount++; // Increment the team counter
            console.log(data);

            // Create a new template of the team item
            const newTeamItem = document.createElement('div');
            newTeamItem.classList.add('text-center');
            newTeamItem.id = `teamItem${teamCount}`;

            // Construct the inner HTML of the new team item
            newTeamItem.innerHTML = `
            <div class="image-wrapper">
                <img class="rounded-lg w-48 h-48 object-cover mx-auto"
                    src="/static/static_real_estate/img/Team-m-2.png" alt="" id="team-img${teamCount}">
                <input type="file" id="team_image_input${teamCount}" accept="image/png, image/jpeg" style="display: none;">
                <div
                    class="upload-button absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 space-x-4 p-2 hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">
                    <button id="button${teamCount}"
                        class="upload-button text-gray-900 bg-white hover:bg-gray-200 focus:outline-none p-1 rounded"
                        onclick="uploadImage('team-img${teamCount}', 'team_image_input${teamCount}')">
                        <span class="material-icons">upload</span>
                        <span class="tooltip-text">Upload Image</span>
                    </button>
                </div>
            </div>
            <div class="relative">
                <h2 id="team-m${teamCount}-title" class="mt-4 text-xl font-semibold">Team Member</h2>
                <p id="team-m${teamCount}-desc" class="text-gray-600">Member Designation</p>
                <div
                    class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex justify-center items-center space-x-4 p-2 heading-buttons hidden transition-all duration-300 bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 rounded-lg">

                    <!-- Edit button -->
                    <button class="text-gray-900 bg-white hover:bg-gray-200 focus:outline-none edit-btn p-1 rounded"
                        onclick="showEditModal('team-m${teamCount}-title', 'team-m${teamCount}-desc')">
                        <span class="material-icons">create</span>
                        <span class="button-text">Edit</span>
                    </button>
                </div>
            </div>
        `;

            // Append the new team item to the container
            document.getElementById("team-container").appendChild(newTeamItem);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



function uploadImage(imgId, inputId) {
    const imageInput = document.getElementById(inputId);
    imageInput.click();
    imageInput.addEventListener('change', () => {
        const file = imageInput.files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById(imgId).src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}


document.addEventListener('DOMContentLoaded', function () {
    // Get all Wraper delete buttons
    const wrapperDeleteButtons = document.querySelectorAll('.wrapper-delete-btn');

    // Add event listener to each delete button
    wrapperDeleteButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const sectionId = this.dataset.targetSection;

            // Find the section by ID and remove it
            const sectionToDelete = document.getElementById(sectionId);
            if (sectionToDelete) {
                sectionToDelete.remove();
            } else {
                console.error("Section with ID " + sectionId + " not found.");
            }
        })
    })
})

// <script src="/static/static_real_estate/js/script.js"></script>