function regenerateContent(itemId, regenerationType) {
    var user_input = document.getElementById(itemId).innerText.trim();
    var user_org = document.getElementById('title1').innerText.trim();

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/regenerate_content', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById(itemId).innerText = JSON.parse(xhr.responseText).regenerated_content;
        }
    };
    xhr.send('user_input=' + encodeURIComponent(user_input) + '&user_org=' + encodeURIComponent(user_org) + '&regeneration_type=' + encodeURIComponent(regenerationType));
}



function regenerateserviceTitleandDescription(titleId, descriptionId) {
    regenerateContent(titleId, 'regenerate_title');
    regenerateContent(descriptionId, 'regenerate_response');
}

function regeneratefeatureTitleandDescription(titleId, descriptionId) {
    regenerateContent(titleId, 'regenerate_title');
    regenerateContent(descriptionId, 'regenerate_response');
}
function generatewithkey(itemId, keywordInputId, regenerationType) {
    var keyword = document.getElementById(keywordInputId).value.trim();
    if (keyword === "") {
        alert("Please enter a keyword.");
        return;
    }
    regenerateContentWithKeyword(itemId, regenerationType, keyword);
}


function generateWithKeyword(titleId, descriptionId, keywordInputId) {
    var keyword = document.getElementById(keywordInputId).value.trim();
    if (keyword === "") {
        alert("Please enter a keyword.");
        return;
    }
    regenerateContentWithKeyword(titleId, 'regenerate_title', keyword);
    regenerateContentWithKeyword(descriptionId, 'regenerate_response', keyword);
}
function generateWithKey(titleId, descriptionId, keywordInputId) {
    var keyword = document.getElementById(keywordInputId).value.trim();
    if (keyword === "") {
        alert("Please enter a keyword.");
        return;
    }
    regenerateContentWithKeyword(titleId, 'regenerate_dish_title', keyword);
    regenerateContentWithKeyword(descriptionId, 'regenerate_dish_desc', keyword);
}



function regenerateContentWithKeyword(itemId, regenerationType, keyword) {
    var user_org = document.getElementById('title1').innerText.trim();

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/regenerate_content', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById(itemId).innerText = JSON.parse(xhr.responseText).regenerated_content;
        }
    };
    xhr.send('user_org=' + encodeURIComponent(user_org) + '&regeneration_type=' + encodeURIComponent(regenerationType) + '&keyword=' + encodeURIComponent(keyword));
}


function handleInput() {
    // You can implement your logic here for handling input and applying styles
    // Example: Get the edited content
    var editedContent = document.getElementById('itempara1').innerHTML;
    console.log('Edited Content:', editedContent);
}

function regenerateHeadlineAndDescription() {
    regenerateContent('aboutHeadline', 'regenerate_headline');
    regenerateContent('aboutDescription', 'regenerate_description');
}