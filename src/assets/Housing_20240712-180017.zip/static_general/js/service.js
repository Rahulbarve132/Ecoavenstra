let itemIndex = 10; // Start the item index from 10

const addServiceItemButton = document.getElementById("addServiceItemButton");
const serviceItemsContainer = document.getElementById("service-items");

addServiceItemButton.addEventListener("click", function () {
    // Fetch data for the next item index
    fetch('/generate_item_content', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
    })
    .then(response => response.json())
    .then(data => {
        // Extract title and description of the next item based on the item index
        const itemTitleKey = `query_service_title_${itemIndex}`;
        const itemDescriptionKey = `query_service_title_${itemIndex + 1}`;
        const itemTitle = data[itemTitleKey];
        const itemDescription = data[itemDescriptionKey];
        
        // Increment the item index for the next fetch
        itemIndex += 2;

        // Create a new service item div
        const newItem = document.createElement("div");
        newItem.classList.add("col-lg-3", "col-sm-6", "wow", "fadeInUp");

        // Create a unique ID for the new item
        const itemId = "item" + Date.now();

        // Create the content for the new item using the data for the current item
        newItem.innerHTML = `
            <div class="service-item rounded pt-3">
                <div class="p-4">
                    <i class="fa fa-3x fa-user-tie text-primary mb-4"></i>
                    <button class="edit-button2 inline-button" onclick="openEditDialog('${itemId}')">Edit</button>
                    <h5 id="${itemId}" class="editable-text" contenteditable="true" oninput="toggleTextStyle('${itemId}', this)">${itemTitle}</h5>
                    <p>${itemDescription}</p>
                </div>
            </div>
        `;

        // Add the new item to the row
        serviceItemsContainer.appendChild(newItem);

        // Call the function to make the new elements editable and load saved text
        const editableText = newItem.querySelector('.editable-text');
        loadTextAndFontFromLocalStorage(itemId, editableText);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});


        
let focusedElement; // Global variable to store the focused element

function populateFontDropdown(fontSelect) {
    // List of fonts you want to include
    const fontList = [
        'Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Courier New',
        'Verdana', 'Impact', 'Comic Sans MS', 'Trebuchet MS', 'Arial Black'
        // Add more fonts as needed
    ];

    // Populate the dropdown with font options
    fontList.forEach((font) => {
        const option = document.createElement('option');
        option.text = font;
        option.value = font;
        fontSelect.add(option);
    });
}

// Call populateFontDropdown when the page loads
populateFontDropdown(document.getElementById('headingFontSelect'));
populateFontDropdown(document.getElementById('paragraphFontSelect'));

function toggleTextStyle(key, editableElement) {
    // Save the edited text and font to local storage
    saveTextToLocalStorage(key, editableElement.innerHTML);
    saveFontToLocalStorage(key, editableElement.style.fontFamily);
    saveFontColorToLocalStorage(key, editableElement.style.color);
}

function saveTextToLocalStorage(key, value) {
    localStorage.setItem(key, value);
}

function loadTextAndFontFromLocalStorage(key, editableElement) {
    const savedText = localStorage.getItem(key);
    const savedFont = localStorage.getItem(`${key}-font`);
    const savedFontColor = localStorage.getItem(`${key}-font-color`);

    if (savedText) {
        editableElement.innerHTML = savedText;
        editableElement.style.fontFamily = savedFont;
        editableElement.style.color = savedFontColor;
    }
}

function saveFontToLocalStorage(key, font) {
    localStorage.setItem(`${key}-font`, font);
}

function saveFontColorToLocalStorage(key, fontColor) {
    localStorage.setItem(`${key}-font-color`, fontColor);
}

function openEditDialog(itemId) {
    focusedElement = document.getElementById(itemId);
    
    const editHeadingText = document.getElementById('editHeadingText');
    const headingFontSelect = document.getElementById('headingFontSelect');
    const headingFontColorPicker = document.getElementById('headingFontColorPicker');
    const editParagraphText = document.getElementById('editParagraphText');
    const paragraphFontSelect = document.getElementById('paragraphFontSelect');
    const paragraphFontColorPicker = document.getElementById('paragraphFontColorPicker');
    const cardBackgroundColorPicker = document.getElementById('cardBackgroundColorPicker');

    // Set values based on the focused element
    if (focusedElement.tagName.toLowerCase() === 'h5') {
        // Heading element
        editHeadingText.value = focusedElement.innerText;
        headingFontSelect.value = focusedElement.style.fontFamily;
        headingFontColorPicker.value = focusedElement.style.color;
    } else if (focusedElement.tagName.toLowerCase() === 'p') {
        // Paragraph element
        editParagraphText.value = focusedElement.innerText;
        paragraphFontSelect.value = focusedElement.style.fontFamily;
        paragraphFontColorPicker.value = focusedElement.style.color;
    }

    // Set card background color
    cardBackgroundColorPicker.value = focusedElement.closest('.service-item').style.backgroundColor;

    document.getElementById('editDialog').style.display = 'block';
}

function closeEditDialog() {
    document.getElementById('editDialog').style.display = 'none';
}

function saveEditContent() {
    const editHeadingText = document.getElementById('editHeadingText');
    const headingFontSelect = document.getElementById('headingFontSelect');
    const headingFontColorPicker = document.getElementById('headingFontColorPicker');
    const editParagraphText = document.getElementById('editParagraphText');
    const paragraphFontSelect = document.getElementById('paragraphFontSelect');
    const paragraphFontColorPicker = document.getElementById('paragraphFontColorPicker');
    const cardBackgroundColorPicker = document.getElementById('cardBackgroundColorPicker');

    // Update styles for the focused element
    focusedElement.innerHTML = editHeadingText.value;
    focusedElement.style.fontFamily = headingFontSelect.value;
    focusedElement.style.color = headingFontColorPicker.value;

    // Update styles for the paragraph element
    const paragraphElement = focusedElement.nextElementSibling;
    paragraphElement.innerHTML = editParagraphText.value;
    paragraphElement.style.fontFamily = paragraphFontSelect.value;
    paragraphElement.style.color = paragraphFontColorPicker.value;

    // Update card background color
    focusedElement.closest('.service-item').style.backgroundColor = cardBackgroundColorPicker.value;

    // ... Your existing code for saving to local storage ...

    closeEditDialog();
}   

function loadTextFontAndColorFromLocalStorage(key, editableElement) {
    const savedText = localStorage.getItem(key);
    const savedFont = localStorage.getItem(`${key}-font`);
    const savedFontColor = localStorage.getItem(`${key}-font-color`);

    if (savedText) {
        editableElement.innerHTML = savedText;
        editableElement.style.fontFamily = savedFont;
        editableElement.style.color = savedFontColor;
    }
}

function loadTextFontAndColorOnPageLoad() {
    const editableElements = document.querySelectorAll('.editable-text');
    editableElements.forEach((element) => {
        loadTextFontAndColorFromLocalStorage(element.id, element);
    });
}

// Call loadTextFontAndColorOnPageLoad when the page loads
if (typeof itemCount === 'undefined') {
    let itemCount = 0;
}

// code for regeneration f title
// code for regeneration f title






// image regenartion
// function regenerateImage() {
//     // Get the user input (you may adjust this based on how you obtain user input)
//     var userInput = prompt("Enter a keyword for the new image:");

//     // Make sure userInput is not empty before making the request
//     if (userInput) {
//         // Make an AJAX request to the server with the user-provided text
//         fetch('/regenerate_image/' + encodeURIComponent(userInput))
//             .then(response => response.json())
//             .then(data => {
//                 // Update the image source with the new URL
//                 var newImageUrl = data.image_data[0]['urls']['regular'];
//                 document.getElementById('imagetwo').src = newImageUrl;
//             })
//             .catch(error => console.error('Error:', error));
//     }
// }

